/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;
const DB_FILE = path.join(process.cwd(), 'database.json');

app.use(express.json());

// Initialize Gemini Client with correct User-Agent for AI Studio telemetry
const geminiApiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (geminiApiKey && geminiApiKey !== 'MY_GEMINI_API_KEY') {
  try {
    ai = new GoogleGenAI({
      apiKey: geminiApiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    console.log('Gemini AI Service successfully initialized.');
  } catch (error) {
    console.error('Failed to initialize Gemini AI Client:', error);
  }
} else {
  console.log('Gemini API key is not configured. Falling back to rule-based logic.');
}

// ==========================================
// DB TYPES & STRUCTS
// ==========================================
interface DBUser {
  id: string;
  email: string;
  passwordHash: string;
  salt: string;
  createdAt: string;
}

interface DBExpense {
  id: string;
  userId: string;
  amount: number;
  category: string;
  date: string;
  paymentMethod: string;
  description: string;
  isRecurring: boolean;
  isAiPredicted?: boolean;
  detectedAnomaly?: boolean;
  anomalyReason?: string;
  createdAt: string;
}

interface DBBudget {
  id: string;
  userId: string;
  category: string;
  amount: number;
  month: string; // YYYY-MM
}

interface DBIncome {
  id: string;
  userId: string;
  amount: number;
  date: string;
  source: string;
  description?: string;
  createdAt: string;
}

interface DBRecurringExpense {
  id: string;
  userId: string;
  amount: number;
  category: string;
  frequency: 'weekly' | 'monthly' | 'yearly';
  startDate: string;
  nextRunDate: string;
  description: string;
}

interface DBStructure {
  users: DBUser[];
  expenses: DBExpense[];
  budgets: DBBudget[];
  incomes: DBIncome[];
  recurringExpenses: DBRecurringExpense[];
}

// Initialize database with premium demo data if it doesn't exist
function initDB(): DBStructure {
  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data);
    } catch (e) {
      console.error('Error reading database file, recreating:', e);
    }
  }

  // Generate Demo User with password 'password123'
  const salt = crypto.randomBytes(16).toString('hex');
  const passwordHash = crypto.pbkdf2Sync('password123', salt, 1000, 64, 'sha512').toString('hex');
  const demoUserId = 'demo-user-uuid-12345';

  const initialDB: DBStructure = {
    users: [
      {
        id: demoUserId,
        email: 'demo@finai.com',
        passwordHash,
        salt,
        createdAt: new Date().toISOString(),
      }
    ],
    expenses: [
      {
        id: 'exp-1',
        userId: demoUserId,
        amount: 24.50,
        category: 'Food & Dining',
        date: '2026-06-24',
        paymentMethod: 'Credit Card',
        description: 'Uber Eats breakfast',
        isRecurring: false,
        isAiPredicted: true,
        detectedAnomaly: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'exp-2',
        userId: demoUserId,
        amount: 10.99,
        category: 'Entertainment & Subscriptions',
        date: '2026-06-23',
        paymentMethod: 'Credit Card',
        description: 'Spotify Premium subscription',
        isRecurring: true,
        isAiPredicted: false,
        detectedAnomaly: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'exp-3',
        userId: demoUserId,
        amount: 45.20,
        category: 'Shopping',
        date: '2026-06-22',
        paymentMethod: 'Debit Card',
        description: 'Amazon.com order - books and notes',
        isRecurring: false,
        isAiPredicted: true,
        detectedAnomaly: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'exp-4',
        userId: demoUserId,
        amount: 15.00,
        category: 'Transport & Travel',
        date: '2026-06-22',
        paymentMethod: 'Cash',
        description: 'Metro card refill',
        isRecurring: false,
        isAiPredicted: false,
        detectedAnomaly: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'exp-5',
        userId: demoUserId,
        amount: 120.00,
        category: 'Utilities & Bills',
        date: '2026-06-20',
        paymentMethod: 'Bank Transfer',
        description: 'Electricity Bill',
        isRecurring: true,
        isAiPredicted: false,
        detectedAnomaly: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'exp-6',
        userId: demoUserId,
        amount: 340.00,
        category: 'Shopping',
        date: '2026-06-18',
        paymentMethod: 'Credit Card',
        description: 'New mechanical keyboard and mouse',
        isRecurring: false,
        isAiPredicted: true,
        detectedAnomaly: true,
        anomalyReason: 'Unusually high amount for Shopping. Standard transactions are under $100.',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'exp-7',
        userId: demoUserId,
        amount: 45.00,
        category: 'Food & Dining',
        date: '2026-06-15',
        paymentMethod: 'Credit Card',
        description: 'Starbucks coffee package and snacks',
        isRecurring: false,
        isAiPredicted: true,
        detectedAnomaly: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'exp-8',
        userId: demoUserId,
        amount: 800.00,
        category: 'Utilities & Bills',
        date: '2026-06-01',
        paymentMethod: 'Bank Transfer',
        description: 'Monthly Apartment Rent',
        isRecurring: true,
        isAiPredicted: false,
        detectedAnomaly: false,
        createdAt: new Date().toISOString(),
      }
    ],
    budgets: [
      {
        id: 'b-1',
        userId: demoUserId,
        category: 'All',
        amount: 2000.00,
        month: '2026-06',
      },
      {
        id: 'b-2',
        userId: demoUserId,
        category: 'Food & Dining',
        amount: 400.00,
        month: '2026-06',
      },
      {
        id: 'b-3',
        userId: demoUserId,
        category: 'Shopping',
        amount: 300.00,
        month: '2026-06',
      },
      {
        id: 'b-4',
        userId: demoUserId,
        category: 'Entertainment & Subscriptions',
        amount: 150.00,
        month: '2026-06',
      }
    ],
    incomes: [
      {
        id: 'inc-1',
        userId: demoUserId,
        amount: 2500.00,
        date: '2026-06-01',
        source: 'Software Engineering Intern Salary',
        description: 'Monthly stipend credit',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'inc-2',
        userId: demoUserId,
        amount: 400.00,
        date: '2026-06-12',
        source: 'Freelance Design Work',
        description: 'Logo package commission payout',
        createdAt: new Date().toISOString(),
      }
    ],
    recurringExpenses: [
      {
        id: 'rec-1',
        userId: demoUserId,
        amount: 10.99,
        category: 'Entertainment & Subscriptions',
        frequency: 'monthly',
        startDate: '2026-01-01',
        nextRunDate: '2026-07-23',
        description: 'Spotify Premium subscription',
      },
      {
        id: 'rec-2',
        userId: demoUserId,
        amount: 120.00,
        category: 'Utilities & Bills',
        frequency: 'monthly',
        startDate: '2026-02-01',
        nextRunDate: '2026-07-20',
        description: 'Electricity Bill',
      }
    ]
  };

  fs.writeFileSync(DB_FILE, JSON.stringify(initialDB, null, 2), 'utf-8');
  return initialDB;
}

let db = initDB();

function saveDB() {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
}

// ==========================================
// AUTH SECURITY MIDDLEWARE
// ==========================================
const SESSION_SECRET = process.env.SESSION_SECRET || 'finai-secret-key-1337-college-project';

function generateToken(userId: string): string {
  const expiration = Date.now() + 1000 * 60 * 60 * 24; // 24 hours
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify({ sub: userId, exp: expiration })).toString('base64url');
  const signature = crypto.createHmac('sha256', SESSION_SECRET).update(`${header}.${payload}`).digest('base64url');
  return `${header}.${payload}.${signature}`;
}

function verifyToken(token: string): string | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, payload, signature] = parts;
    const expectedSignature = crypto.createHmac('sha256', SESSION_SECRET).update(`${header}.${payload}`).digest('base64url');
    if (signature !== expectedSignature) return null;

    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8'));
    if (data.exp < Date.now()) return null; // expired
    return data.sub;
  } catch (e) {
    return null;
  }
}

// Express Auth Middleware
function requireAuth(req: any, res: any, next: any) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or malformed Authorization header' });
  }

  const token = authHeader.split(' ')[1];
  const userId = verifyToken(token);
  if (!userId) {
    return res.status(401).json({ error: 'Invalid or expired access token' });
  }

  // Check if user still exists
  const user = db.users.find(u => u.id === userId);
  if (!user) {
    return res.status(401).json({ error: 'User no longer exists' });
  }

  req.userId = userId;
  next();
}

// ==========================================
// AI / ML CORE HEURISTIC & GEMINI SERVICES
// ==========================================

// Standard categorizer fallback rules (Heuristics)
function runRuleBasedCategorizer(text: string): string {
  const lowercase = text.toLowerCase();
  if (lowercase.includes('uber') || lowercase.includes('lyft') || lowercase.includes('cab') || lowercase.includes('metro') || lowercase.includes('bus') || lowercase.includes('flight') || lowercase.includes('train') || lowercase.includes('petrol') || lowercase.includes('gas')) {
    return 'Transport & Travel';
  }
  if (lowercase.includes('starbucks') || lowercase.includes('swiggy') || lowercase.includes('zomato') || lowercase.includes('food') || lowercase.includes('dinner') || lowercase.includes('lunch') || lowercase.includes('breakfast') || lowercase.includes('restaurant') || lowercase.includes('cafe') || lowercase.includes('pizza') || lowercase.includes('burger')) {
    return 'Food & Dining';
  }
  if (lowercase.includes('netflix') || lowercase.includes('spotify') || lowercase.includes('prime') || lowercase.includes('steam') || lowercase.includes('game') || lowercase.includes('disney') || lowercase.includes('hulu') || lowercase.includes('subscription')) {
    return 'Entertainment & Subscriptions';
  }
  if (lowercase.includes('rent') || lowercase.includes('electric') || lowercase.includes('water') || lowercase.includes('gas bill') || lowercase.includes('phone bill') || lowercase.includes('wifi') || lowercase.includes('internet')) {
    return 'Utilities & Bills';
  }
  if (lowercase.includes('amazon') || lowercase.includes('target') || lowercase.includes('walmart') || lowercase.includes('shopping') || lowercase.includes('clothing') || lowercase.includes('mall') || lowercase.includes('sneakers') || lowercase.includes('buy') || lowercase.includes('keyboard')) {
    return 'Shopping';
  }
  return 'Miscellaneous';
}

// AI NLP Categorization with robust fallback
async function predictCategoryAI(description: string): Promise<{ category: string; isAiPredicted: boolean }> {
  if (!ai) {
    // Fall back to rules
    return { category: runRuleBasedCategorizer(description), isAiPredicted: false };
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `You are an expert personal finance assistant. Categorize the transaction description: "${description}" into exactly one of these 6 categories:
- Food & Dining
- Transport & Travel
- Shopping
- Entertainment & Subscriptions
- Utilities & Bills
- Miscellaneous

Your response must be a single line containing only the category name exactly as written above. Do not include any punctuation, quotes, or markdown formatting.`,
    });

    const predicted = response.text?.trim() || '';
    const validCategories = [
      'Food & Dining',
      'Transport & Travel',
      'Shopping',
      'Entertainment & Subscriptions',
      'Utilities & Bills',
      'Miscellaneous',
    ];

    if (validCategories.includes(predicted)) {
      return { category: predicted, isAiPredicted: true };
    } else {
      // Find matching category or rule based
      const found = validCategories.find(c => c.toLowerCase() === predicted.toLowerCase());
      if (found) {
        return { category: found, isAiPredicted: true };
      }
      return { category: runRuleBasedCategorizer(description), isAiPredicted: false };
    }
  } catch (error) {
    console.error('Gemini classification error:', error);
    return { category: runRuleBasedCategorizer(description), isAiPredicted: false };
  }
}

// Anomaly detection rules
function detectExpenseAnomaly(userId: string, category: string, amount: number): { isAnomaly: boolean; reason?: string } {
  const userExpenses = db.expenses.filter(e => e.userId === userId && e.category === category);
  if (userExpenses.length < 3) {
    // Not enough baseline history
    return { isAnomaly: false };
  }

  const amounts = userExpenses.map(e => e.amount);
  const sum = amounts.reduce((a, b) => a + b, 0);
  const mean = sum / amounts.length;

  // Let's calculate standard deviation
  const variance = amounts.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / amounts.length;
  const stdDev = Math.sqrt(variance);

  // If the new amount is > 2.5 standard deviations above the mean, OR 3x the mean for this category
  const threshold = Math.max(mean + 2.5 * stdDev, mean * 3.0);

  if (amount > threshold) {
    return {
      isAnomaly: true,
      reason: `This transaction of $${amount.toFixed(2)} is significantly higher than your typical average spend of $${mean.toFixed(2)} for ${category}.`,
    };
  }

  return { isAnomaly: false };
}

// ==========================================
// REST API ENDPOINTS
// ==========================================

// Health Check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', databasePath: DB_FILE, geminiConfigured: !!ai });
});

// Register
app.post('/api/auth/register', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const normalizedEmail = email.trim().toLowerCase();
  const existing = db.users.find(u => u.email === normalizedEmail);
  if (existing) {
    return res.status(400).json({ error: 'A user with this email already exists' });
  }

  const id = 'user-' + crypto.randomUUID();
  const salt = crypto.randomBytes(16).toString('hex');
  const passwordHash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');

  const newUser: DBUser = {
    id,
    email: normalizedEmail,
    passwordHash,
    salt,
    createdAt: new Date().toISOString(),
  };

  db.users.push(newUser);
  saveDB();

  // Also pre-populate a few budgets for new users to make experience beautiful
  const currentMonth = new Date().toISOString().substring(0, 7); // YYYY-MM
  db.budgets.push(
    { id: crypto.randomUUID(), userId: id, category: 'All', amount: 1500, month: currentMonth },
    { id: crypto.randomUUID(), userId: id, category: 'Food & Dining', amount: 300, month: currentMonth },
    { id: crypto.randomUUID(), userId: id, category: 'Shopping', amount: 200, month: currentMonth }
  );
  saveDB();

  const token = generateToken(id);
  res.status(201).json({
    user: { id, email: normalizedEmail, createdAt: newUser.createdAt },
    token,
  });
});

// Login
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const normalizedEmail = email.trim().toLowerCase();
  const user = db.users.find(u => u.email === normalizedEmail);
  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password credentials' });
  }

  const hash = crypto.pbkdf2Sync(password, user.salt, 1000, 64, 'sha512').toString('hex');
  if (hash !== user.passwordHash) {
    return res.status(401).json({ error: 'Invalid email or password credentials' });
  }

  const token = generateToken(user.id);
  res.json({
    user: { id: user.id, email: user.email, createdAt: user.createdAt },
    token,
  });
});

// Get Current User Profile
app.get('/api/auth/me', requireAuth, (req: any, res) => {
  const user = db.users.find(u => u.id === req.userId);
  if (!user) {
    return res.status(404).json({ error: 'User profile not found' });
  }
  res.json({ id: user.id, email: user.email, createdAt: user.createdAt });
});

// ------------------------------------------
// EXPENSES LEDGER ENDPOINTS
// ------------------------------------------

// List expenses with query filters
app.get('/api/expenses', requireAuth, (req: any, res) => {
  let list = db.expenses.filter(e => e.userId === req.userId);

  const { category, search, startDate, endDate } = req.query;

  if (category && category !== 'All') {
    list = list.filter(e => e.category === category);
  }

  if (search) {
    const searchStr = String(search).toLowerCase();
    list = list.filter(
      e => e.description.toLowerCase().includes(searchStr) || e.paymentMethod.toLowerCase().includes(searchStr)
    );
  }

  if (startDate) {
    list = list.filter(e => e.date >= String(startDate));
  }

  if (endDate) {
    list = list.filter(e => e.date <= String(endDate));
  }

  // Sort descending by date, then by creation time
  list.sort((a, b) => {
    if (a.date !== b.date) {
      return b.date.localeCompare(a.date);
    }
    return b.createdAt.localeCompare(a.createdAt);
  });

  res.json(list);
});

// Create expense with intelligent auto-categorizer & anomaly checks
app.post('/api/expenses', requireAuth, async (req: any, res) => {
  const { amount, date, paymentMethod, description, category, isRecurring } = req.body;

  if (amount === undefined || !date || !description) {
    return res.status(400).json({ error: 'Amount, date, and description are required fields' });
  }

  const expenseAmount = parseFloat(amount);
  if (isNaN(expenseAmount) || expenseAmount <= 0) {
    return res.status(400).json({ error: 'Amount must be a valid positive number' });
  }

  // AI Classification or Heuristics if left blank or specified as auto
  let finalCategory = category;
  let isAiPredicted = false;

  if (!category || category === 'Auto (AI)') {
    const aiResult = await predictCategoryAI(description);
    finalCategory = aiResult.category;
    isAiPredicted = aiResult.isAiPredicted;
  }

  // Anomaly Detection
  const anomalyCheck = detectExpenseAnomaly(req.userId, finalCategory, expenseAmount);

  const newExpense: DBExpense = {
    id: 'exp-' + crypto.randomUUID(),
    userId: req.userId,
    amount: expenseAmount,
    category: finalCategory,
    date,
    paymentMethod: paymentMethod || 'Debit Card',
    description: description.trim(),
    isRecurring: !!isRecurring,
    isAiPredicted,
    detectedAnomaly: anomalyCheck.isAnomaly,
    anomalyReason: anomalyCheck.reason,
    createdAt: new Date().toISOString(),
  };

  db.expenses.push(newExpense);
  saveDB();

  res.status(201).json(newExpense);
});

// Update expense
app.put('/api/expenses/:id', requireAuth, async (req: any, res) => {
  const { id } = req.params;
  const { amount, date, paymentMethod, description, category, isRecurring } = req.body;

  const index = db.expenses.findIndex(e => e.id === id && e.userId === req.userId);
  if (index === -1) {
    return res.status(404).json({ error: 'Expense item not found' });
  }

  const currentExpense = db.expenses[index];

  if (amount !== undefined) {
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) {
      return res.status(400).json({ error: 'Amount must be a positive number' });
    }
    currentExpense.amount = val;
  }

  if (date) currentExpense.date = date;
  if (paymentMethod) currentExpense.paymentMethod = paymentMethod;
  if (description) currentExpense.description = description.trim();
  if (isRecurring !== undefined) currentExpense.isRecurring = !!isRecurring;

  if (category) {
    currentExpense.category = category;
    currentExpense.isAiPredicted = false; // Overridden manually
  }

  // Re-run anomaly checks based on updated amount/category
  const anomalyCheck = detectExpenseAnomaly(req.userId, currentExpense.category, currentExpense.amount);
  currentExpense.detectedAnomaly = anomalyCheck.isAnomaly;
  currentExpense.anomalyReason = anomalyCheck.reason;

  db.expenses[index] = currentExpense;
  saveDB();

  res.json(currentExpense);
});

// Delete expense
app.delete('/api/expenses/:id', requireAuth, (req: any, res) => {
  const { id } = req.params;
  const initialLength = db.expenses.length;
  db.expenses = db.expenses.filter(e => !(e.id === id && e.userId === req.userId));

  if (db.expenses.length === initialLength) {
    return res.status(404).json({ error: 'Expense item not found' });
  }

  saveDB();
  res.json({ success: true, message: 'Expense deleted successfully' });
});

// ------------------------------------------
// BUDGETS ENDPOINTS
// ------------------------------------------

// Get budgets status
app.get('/api/budgets/status', requireAuth, (req: any, res) => {
  const userBudgets = db.budgets.filter(b => b.userId === req.userId);
  const userExpenses = db.expenses.filter(e => e.userId === req.userId);

  // Filter current month's expenses
  const currentMonthStr = new Date().toISOString().substring(0, 7); // YYYY-MM
  const currentMonthExpenses = userExpenses.filter(e => e.date.substring(0, 7) === currentMonthStr);

  const statusList = userBudgets.map(b => {
    let spent = 0;
    if (b.category === 'All') {
      spent = currentMonthExpenses.reduce((sum, e) => sum + e.amount, 0);
    } else {
      spent = currentMonthExpenses
        .filter(e => e.category === b.category)
        .reduce((sum, e) => sum + e.amount, 0);
    }

    return {
      id: b.id,
      category: b.category,
      limit: b.amount,
      spent: parseFloat(spent.toFixed(2)),
      percentageUsed: b.amount > 0 ? parseFloat(((spent / b.amount) * 100).toFixed(1)) : 0,
      month: b.month,
    };
  });

  res.json(statusList);
});

// Create/Update category budget
app.post('/api/budgets', requireAuth, (req: any, res) => {
  const { category, amount, month } = req.body;

  if (!category || amount === undefined || !month) {
    return res.status(400).json({ error: 'Category, amount, and month are required' });
  }

  const budgetAmount = parseFloat(amount);
  if (isNaN(budgetAmount) || budgetAmount < 0) {
    return res.status(400).json({ error: 'Budget limit amount must be a positive number' });
  }

  // Check if budget for this category and month already exists
  const existingIndex = db.budgets.findIndex(
    b => b.userId === req.userId && b.category === category && b.month === month
  );

  if (existingIndex !== -1) {
    db.budgets[existingIndex].amount = budgetAmount;
    saveDB();
    return res.json(db.budgets[existingIndex]);
  }

  const newBudget: DBBudget = {
    id: 'b-' + crypto.randomUUID(),
    userId: req.userId,
    category,
    amount: budgetAmount,
    month,
  };

  db.budgets.push(newBudget);
  saveDB();

  res.status(201).json(newBudget);
});

// Delete category budget
app.delete('/api/budgets/:id', requireAuth, (req: any, res) => {
  const { id } = req.params;
  const initialLength = db.budgets.length;
  db.budgets = db.budgets.filter(b => !(b.id === id && b.userId === req.userId));

  if (db.budgets.length === initialLength) {
    return res.status(404).json({ error: 'Budget item not found' });
  }

  saveDB();
  res.json({ success: true, message: 'Category budget removed successfully' });
});

// ------------------------------------------
// INCOME ENDPOINTS
// ------------------------------------------

// List Income
app.get('/api/income', requireAuth, (req: any, res) => {
  const list = db.incomes.filter(i => i.userId === req.userId);
  list.sort((a, b) => b.date.localeCompare(a.date));
  res.json(list);
});

// Add Income
app.post('/api/income', requireAuth, (req: any, res) => {
  const { amount, date, source, description } = req.body;

  if (amount === undefined || !date || !source) {
    return res.status(400).json({ error: 'Amount, date, and source are required' });
  }

  const incomeAmount = parseFloat(amount);
  if (isNaN(incomeAmount) || incomeAmount <= 0) {
    return res.status(400).json({ error: 'Income amount must be a valid positive number' });
  }

  const newIncome: DBIncome = {
    id: 'inc-' + crypto.randomUUID(),
    userId: req.userId,
    amount: incomeAmount,
    date,
    source: source.trim(),
    description: description ? description.trim() : undefined,
    createdAt: new Date().toISOString(),
  };

  db.incomes.push(newIncome);
  saveDB();

  res.status(201).json(newIncome);
});

// Delete Income
app.delete('/api/income/:id', requireAuth, (req: any, res) => {
  const { id } = req.params;
  const initialLength = db.incomes.length;
  db.incomes = db.incomes.filter(i => !(i.id === id && i.userId === req.userId));

  if (db.incomes.length === initialLength) {
    return res.status(404).json({ error: 'Income item not found' });
  }

  saveDB();
  res.json({ success: true, message: 'Income item deleted successfully' });
});

// ------------------------------------------
// RECURRING EXPENSES ENDPOINTS
// ------------------------------------------

// List Recurring Expenses
app.get('/api/recurring-expenses', requireAuth, (req: any, res) => {
  const list = db.recurringExpenses.filter(r => r.userId === req.userId);
  res.json(list);
});

// Create Recurring Expense
app.post('/api/recurring-expenses', requireAuth, (req: any, res) => {
  const { amount, category, frequency, startDate, description } = req.body;

  if (amount === undefined || !category || !frequency || !startDate || !description) {
    return res.status(400).json({ error: 'Amount, category, frequency, startDate, and description are required' });
  }

  const recAmount = parseFloat(amount);
  if (isNaN(recAmount) || recAmount <= 0) {
    return res.status(400).json({ error: 'Amount must be a positive number' });
  }

  const newRec: DBRecurringExpense = {
    id: 'rec-' + crypto.randomUUID(),
    userId: req.userId,
    amount: recAmount,
    category,
    frequency,
    startDate,
    nextRunDate: startDate, // Init to start date
    description: description.trim(),
  };

  db.recurringExpenses.push(newRec);
  saveDB();

  res.status(201).json(newRec);
});

// Delete Recurring Expense
app.delete('/api/recurring-expenses/:id', requireAuth, (req: any, res) => {
  const { id } = req.params;
  const initialLength = db.recurringExpenses.length;
  db.recurringExpenses = db.recurringExpenses.filter(r => !(r.id === id && r.userId === req.userId));

  if (db.recurringExpenses.length === initialLength) {
    return res.status(404).json({ error: 'Recurring expense item not found' });
  }

  saveDB();
  res.json({ success: true, message: 'Recurring expense deleted successfully' });
});

// ------------------------------------------
// ANALYTICS & AI DASHBOARD STATUS
// ------------------------------------------

// High-level overview numbers
app.get('/api/analytics/summary', requireAuth, (req: any, res) => {
  const userExpenses = db.expenses.filter(e => e.userId === req.userId);
  const userIncomes = db.incomes.filter(i => i.userId === req.userId);
  const userBudgets = db.budgets.filter(b => b.userId === req.userId);

  const currentMonthStr = new Date().toISOString().substring(0, 7); // YYYY-MM
  const monthExpenses = userExpenses.filter(e => e.date.substring(0, 7) === currentMonthStr);
  const monthIncomes = userIncomes.filter(i => i.date.substring(0, 7) === currentMonthStr);

  const totalSpent = monthExpenses.reduce((sum, e) => sum + e.amount, 0);
  const totalIncome = monthIncomes.reduce((sum, e) => sum + e.amount, 0);
  const netSavings = totalIncome - totalSpent;

  // Active global budget limit
  const globalBudget = userBudgets.find(b => b.category === 'All' && b.month === currentMonthStr);
  const budgetLimit = globalBudget ? globalBudget.amount : 2000; // default benchmark
  const budgetBurnRate = budgetLimit > 0 ? parseFloat(((totalSpent / budgetLimit) * 100).toFixed(1)) : 0;

  res.json({
    totalSpent: parseFloat(totalSpent.toFixed(2)),
    totalIncome: parseFloat(totalIncome.toFixed(2)),
    netSavings: parseFloat(netSavings.toFixed(2)),
    budgetBurnRate,
    budgetLimit,
  });
});

// Category pie stats
app.get('/api/analytics/categories', requireAuth, (req: any, res) => {
  const userExpenses = db.expenses.filter(e => e.userId === req.userId);
  const currentMonthStr = new Date().toISOString().substring(0, 7);
  const monthExpenses = userExpenses.filter(e => e.date.substring(0, 7) === currentMonthStr);

  const categoryTotals: Record<string, number> = {};
  monthExpenses.forEach(e => {
    categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
  });

  const colors: Record<string, string> = {
    'Food & Dining': '#3B82F6', // Blue
    'Transport & Travel': '#10B981', // Emerald
    'Shopping': '#F59E0B', // Amber
    'Entertainment & Subscriptions': '#EC4899', // Pink
    'Utilities & Bills': '#8B5CF6', // Purple
    'Miscellaneous': '#6B7280', // Gray
  };

  const payload = Object.entries(categoryTotals).map(([category, value]) => ({
    category,
    value: parseFloat(value.toFixed(2)),
    color: colors[category] || '#3B82F6',
  }));

  res.json(payload);
});

// Dynamic daily trend chart data
app.get('/api/analytics/trends', requireAuth, (req: any, res) => {
  const userExpenses = db.expenses.filter(e => e.userId === req.userId);
  const userIncomes = db.incomes.filter(i => i.userId === req.userId);

  const currentMonthStr = new Date().toISOString().substring(0, 7);

  // Group by day-of-month
  const dayStats: Record<string, { date: string; expenses: number; income: number }> = {};

  // Initialize for all days of current month up to today
  const today = new Date();
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();

  for (let d = 1; d <= daysInMonth; d++) {
    const dayStr = `${currentMonthStr}-${String(d).padStart(2, '0')}`;
    dayStats[dayStr] = {
      date: dayStr,
      expenses: 0,
      income: 0,
    };
  }

  userExpenses
    .filter(e => e.date.substring(0, 7) === currentMonthStr)
    .forEach(e => {
      if (dayStats[e.date]) {
        dayStats[e.date].expenses += e.amount;
      }
    });

  userIncomes
    .filter(i => i.date.substring(0, 7) === currentMonthStr)
    .forEach(i => {
      if (dayStats[i.date]) {
        dayStats[i.date].income += i.amount;
      }
    });

  const trendData = Object.values(dayStats).sort((a, b) => a.date.localeCompare(b.date));
  res.json(trendData);
});

// AI/ML Smart Forecast spending
app.get('/api/ai/forecast', requireAuth, async (req: any, res) => {
  const userExpenses = db.expenses.filter(e => e.userId === req.userId);
  const userBudgets = db.budgets.filter(b => b.userId === req.userId);

  const currentMonthStr = new Date().toISOString().substring(0, 7);
  const monthExpenses = userExpenses.filter(e => e.date.substring(0, 7) === currentMonthStr);

  const currentSpend = monthExpenses.reduce((sum, e) => sum + e.amount, 0);

  const today = new Date();
  const dayOfMonth = today.getDate();
  const totalDays = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();

  // Baseline standard: linear run-rate pacing
  let projectedSpend = currentSpend;
  if (dayOfMonth > 0) {
    projectedSpend = (currentSpend / dayOfMonth) * totalDays;
  }

  // Get current active budget
  const globalBudget = userBudgets.find(b => b.category === 'All' && b.month === currentMonthStr);
  const limit = globalBudget ? globalBudget.amount : 2000;
  const isOverBudget = projectedSpend > limit;

  // Confidence margins
  const margin = projectedSpend * 0.1; // 10% standard error variance
  const confidenceInterval: [number, number] = [
    parseFloat(Math.max(0, projectedSpend - margin).toFixed(2)),
    parseFloat((projectedSpend + margin).toFixed(2)),
  ];

  let aiExplanation = '';

  if (ai) {
    try {
      const prompt = `As an elite AI financial advisor, summarize this forecasting situation:
- Active Monthly Budget Limit: $${limit}
- Current Spend up to Day ${dayOfMonth} of ${totalDays}: $${currentSpend.toFixed(2)}
- Mathematical Projection: $${projectedSpend.toFixed(2)}

Provide a concise, motivating, single-sentence projection advisory telling the user where they are heading, if they will stay under budget, and 1 smart action they should take based on the math. Make it warm and constructive.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
      });

      aiExplanation = response.text?.trim() || '';
    } catch (e) {
      aiExplanation = `Based on your average pacing of $${(currentSpend / dayOfMonth).toFixed(2)} per day, you are estimated to finish the month at $${projectedSpend.toFixed(2)}, which is ${isOverBudget ? 'above' : 'within'} your budget.`;
    }
  } else {
    aiExplanation = `Based on your average pacing of $${(currentSpend / dayOfMonth).toFixed(2)} per day, you are estimated to finish the month at $${projectedSpend.toFixed(2)}, which is ${isOverBudget ? 'above' : 'within'} your budget.`;
  }

  res.json({
    currentSpend: parseFloat(currentSpend.toFixed(2)),
    projectedSpend: parseFloat(projectedSpend.toFixed(2)),
    isOverBudget,
    confidenceInterval,
    aiExplanation,
  });
});

// AI Personal Smart Insights Engine
app.get('/api/ai/insights', requireAuth, async (req: any, res) => {
  const userExpenses = db.expenses.filter(e => e.userId === req.userId);
  const userBudgets = db.budgets.filter(b => b.userId === req.userId);
  const userIncomes = db.incomes.filter(i => i.userId === req.userId);

  const currentMonthStr = new Date().toISOString().substring(0, 7);
  const monthExpenses = userExpenses.filter(e => e.date.substring(0, 7) === currentMonthStr);

  const totalSpent = monthExpenses.reduce((sum, e) => sum + e.amount, 0);

  // Group spends
  const categoriesMap: Record<string, number> = {};
  monthExpenses.forEach(e => {
    categoriesMap[e.category] = (categoriesMap[e.category] || 0) + e.amount;
  });

  const topCategory = Object.entries(categoriesMap).sort((a, b) => b[1] - a[1])[0]?.[0] || 'None';

  // Anomaly lists
  const anomalies = monthExpenses.filter(e => e.detectedAnomaly);

  // Budgets pacing
  const overpacingBudgets: string[] = [];
  userBudgets.forEach(b => {
    if (b.category === 'All') return;
    const spent = monthExpenses.filter(e => e.category === b.category).reduce((s, e) => s + e.amount, 0);
    if (spent > b.amount * 0.8) {
      overpacingBudgets.push(`${b.category} (${Math.round((spent / b.amount) * 100)}% consumed)`);
    }
  });

  let insightsPayload = [
    {
      id: 'ins-1',
      type: 'info' as const,
      title: 'Top Category Spending',
      message: topCategory !== 'None'
        ? `Your highest discretionary spend category is currently "${topCategory}". Consider reviewing individual transactions here.`
        : 'Welcome! Add your first transactions to begin generating AI financial insights.',
    },
    {
      id: 'ins-2',
      type: 'warning' as const,
      title: 'Budget Alert',
      message: overpacingBudgets.length > 0
        ? `You have reached critical levels for: ${overpacingBudgets.join(', ')}. Try to minimize non-essential spends.`
        : 'Your budget targets are currently on track. Great job pacing your spends!',
    },
    {
      id: 'ins-3',
      type: 'success' as const,
      title: 'Healthy Savings Rate',
      message: 'You have managed to save a positive margin of cash flow this week. Keep up the high savings pace!',
    }
  ];

  // Try to use Gemini to generate highly custom insights if configured
  if (ai && monthExpenses.length > 0) {
    try {
      const summaryData = {
        totalSpent,
        totalIncome: userIncomes.filter(i => i.date.substring(0, 7) === currentMonthStr).reduce((s, i) => s + i.amount, 0),
        topCategory,
        categoryBreakdown: categoriesMap,
        anomalies: anomalies.map(a => ({ desc: a.description, amount: a.amount, category: a.category })),
        budgets: userBudgets.map(b => ({ category: b.category, limit: b.amount })),
      };

      const prompt = `As a friendly, highly skilled AI financial advisor, analyze this monthly spending telemetry for a student/young professional:
${JSON.stringify(summaryData, null, 2)}

Generate EXACTLY 3 insights. One must be a warning/danger if budget is high/anomalies found, one must be a success tip if they are doing well, and one general advice.
You must return the response as a valid JSON array of 3 elements, matching this schema:
[
  {
    "id": "ins-1",
    "type": "danger" | "warning" | "success" | "info",
    "title": "Short title",
    "message": "Specific, actionable, 1-2 sentence insights based on their data. Mention specific numbers or categories if possible."
  },
  ...
]
Do not return any other text, quotes, or markdown code blocks around the JSON output. Just raw JSON.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const parsed = JSON.parse(response.text || '[]');
      if (Array.isArray(parsed) && parsed.length === 3) {
        insightsPayload = parsed;
      }
    } catch (e) {
      console.error('Failed to generate insights with Gemini, falling back to static metrics:', e);
    }
  }

  res.json(insightsPayload);
});

// AI Dry-run text classify tester
app.post('/api/ai/classify-text', requireAuth, async (req: any, res) => {
  const { text } = req.body;
  if (!text) {
    return res.status(400).json({ error: 'Text query description is required' });
  }

  const result = await predictCategoryAI(text);
  res.json({
    predictedCategory: result.category,
    isAiPredicted: result.isAiPredicted,
  });
});

// ==========================================
// VITE DEV SERVER OR STATIC SERVING IN PRODUCTION
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
