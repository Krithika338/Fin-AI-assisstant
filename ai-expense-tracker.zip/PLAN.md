# AI-Powered Expense Tracker / Personal Finance Assistant
## Master Planning, Architecture & Implementation Blueprint

This comprehensive document serves as the architectural blueprint and step-by-step implementation guide for building a production-grade, full-stack **AI-Powered Expense Tracker and Personal Finance Assistant**. It is specifically tailored as a standout resume project for a college student targeting competitive full-stack or ML-adjacent software engineering roles.

---

## 1. Project Overview

### What the App Does
The **AI-Powered Expense Tracker / Personal Finance Assistant** is a web-based financial intelligence dashboard. It automates expense tracking, budget enforcement, and cash flow prediction. Beyond standard CRUD operations, the application integrates machine learning algorithms to classify transaction descriptions, forecast future month-end balances, identify anomalous transactions (such as billing errors or sudden spending spikes), and deliver hyper-personalized financial tips.

### What Problem It Solves
Most personal finance tools fail because of the **friction of manual entry** and the **lack of actionable foresight**. Users struggle to remember to categorize expenses and rarely understand where their budget is heading until they have already overspent. 
This application solves these pain points by:
1. **Removing input friction** through natural language description auto-categorization.
2. **Shifting focus from retrospective to prospective analysis** by forecasting month-end expenses based on historical run rates.
3. **Providing active safeguarding** through real-time anomaly detection and smart insights.

### Who the Users Are
- **College Students and Young Professionals** looking to stay within tight budgets.
- **Gig Workers and Freelancers** who require dynamic cash-flow monitoring across multiple, unstructured revenue streams.
- **Budget-conscious individuals** who want automated, self-hosted financial reporting.

### Why This is a Standout Resume Project
- **Demonstrates Production Practices**: Avoids monolithic structures by using a modular, clean, and separation-of-concerns-focused design.
- **Full-Stack & Relational Integrity**: Implements rigorous PostgreSQL relational constraints, indexes, and transactions using SQLAlchemy and FastAPI.
- **Real-world AI Integration**: Rather than utilizing external API "wrappers" (which can feel shallow to interviewers), this project features a **locally deployed, self-trained Scikit-Learn pipeline** that performs natural language classification, statistical forecasting, and unsupervised anomaly detection on server-side background workers.
- **Optimized Performance**: Employs backend optimization techniques like custom database indexes and analytical queries to deliver responsive, interactive charts.

---

## 2. Feature Levels (Grouped by Scope)

### Level 1 — Core App (The Foundation)
*These form the essential structural foundation. They must be robust and secure before any intelligent features are added.*
- **Secure User Authentication**: Registration and login using FastAPI’s OAuth2 with password hashing (via `bcrypt`) and JWT (JSON Web Tokens) stored securely.
- **Expense CRUD Engine**: Creating, reading, updating, and deleting transactions with attributes: `amount` (numeric, high-precision), `category` (FK), `date`, `payment_method`, and `description`.
- **Monthly Budget Setting**: Setting limits per category or globally, and displaying a visual progress tracker.
- **Interactive Dashboard**: Modern analytics dashboard using Recharts featuring monthly spending trends and category-wise breakdowns.
- **Advanced Filtering & History**: Tabular view of transactions with client/server-side filters by category, date range, and payment method.

### Level 2 — Smart Finance Features
*These transition the app from a simple CRUD system into an active utility tool.*
- **Recurring Expenses Engine**: An automated scheduler (weekly, monthly, yearly) that pre-registers expected bills (e.g., Netflix, Rent).
- **Income & Cash Flow Tracking**: Tracking salary, gig work, or transfers to calculate net monthly savings rate.
- **Budget Alerts**: Triggering interactive UI notifications or email alerts when spending crosses critical thresholds (e.g., 50%, 80%, 100% of a budget limit).
- **Search Engine**: Full-text keyword search over expense descriptions.
- **Savings Summary & Reports**: An end-of-month financial report page displaying detailed net metrics and a downloadable summary.

### Level 3 — AI Features
*The competitive differentiators. These introduce machine learning and statistical models into the backend service pipeline.*
- **NLP Transaction Categorizer**: Multi-class text classification using an offline `TF-IDF Vectorizer + Logistic Regression` model trained on a transaction corpus.
- **Monthly Spending Predictor**: Time-series linear regression and rolling-average models projecting current month-end total spending based on day-of-month progress and historical patterns.
- **Anomaly Detection**: Unsupervised statistical z-score models flagging expenses that diverge significantly from historical trends in a category.
- **Dynamic Heuristic Insights**: An analytical script analyzing week-over-week trends to identify specific spending habits (e.g., "Shopping spends have risen by 32% this week, driven primarily by weekend transactions").

---

## 3. High-Level Architecture

```
                                  +-------------------+
                                  |   React Client    |
                                  | (Vite + Recharts) |
                                  +---------+---------+
                                            ^
                                            | JSON APIs (Fetch/Axios)
                                            v
                                  +---------+---------+
                                  |  FastAPI Server  |
                                  +----+---------+----+
                                       |         |
                  SQLAlchemy ORM Queries|         | Joblib / Scikit-Learn
                                       v         v
                             +---------+----+  +--+-----------------+
                             |  PostgreSQL  |  |  ML Model Engine   |
                             |  Database    |  | (Local Classifier) |
                             +--------------+  +--------------------+
```

### 1. Architectural Flow
- **Frontend Layer**: Built using React, styled with Tailwind CSS, using Recharts for data visualization and React Router for view management. All API calls are directed to the FastAPI gateway.
- **Backend Layer**: A modular FastAPI application that utilizes asynchronous handlers, Pydantic schemas, and SQLAlchemy for ORM interactions.
- **Database Layer**: PostgreSQL stores relational data securely. Indexes are placed on foreign key constraints and frequently filtered columns (`user_id`, `date`, `category_id`).
- **AI/ML Layer**: Implemented inside the Python environment. Models are pre-trained on a separate background pipeline, serialized using `joblib`, and loaded into FastAPI memory on startup for low-latency, real-time predictions.

### 2. Detailed Data Flow
1. **Registration & Auth**: The user registers. The password is encrypted with `bcrypt` and stored. Upon login, a JWT is issued.
2. **Transaction Insertion**:
   - The user inputs: *"Swiggy lunch with teammates"* (amount: `$24.50`, category: left blank).
   - The React client sends a `POST` request to `/api/expenses`.
   - FastAPI intercepts the request, checks auth, and triggers the **NLP Categorization Service**.
   - The service sanitizes the text, passes it through the pre-loaded `TF-IDF + Logistic Regression` model, and classifies it as **Food/Dining** (92% confidence).
   - The transaction is saved in PostgreSQL with the predicted category.
   - The response containing the classified transaction is returned to the client.
3. **Analytics Refresh**: The dashboard queries `/api/analytics/dashboard`. Aggregation queries calculate the total spend, category-wise breakdown, and budget usage, returning a clean payload to refresh Recharts instantly.

---

## 4. Database Schema (PostgreSQL)

```
       +-----------------------+                    +-----------------------+
       |         users         |                    |      categories       |
       +-----------------------+                    +-----------------------+
       | PK | id (UUID)        |<--+                | PK | id (SERIAL)      |<--+
       |    | email (VARCHAR)  |   |                |    | name (VARCHAR)   |   |
       |    | hashed_pw (TEXT) |   |                |    | icon (VARCHAR)   |   |
       |    | created_at (TZ)  |   |                +-----------------------+   |
       +-----------------------+   |                                            |
                                   |                                            |
       +-----------------------+   |                +-----------------------+   |
       |        budgets        |   |                |       expenses        |   |
       +-----------------------+   |                +-----------------------+   |
       | PK | id (UUID)        |   |                | PK | id (UUID)        |   |
       | FK | user_id -------->+   +--------------->| FK | user_id          |   |
       | FK | category_id ---->+------------------->| FK | category_id ---->+   |
       |    | amount (NUMERIC) |   |                |    | amount (NUMERIC) |   |
       |    | month (DATE)     |   |                |    | date (DATE)      |   |
       +-----------------------+   |                |    | pay_method (STR) |   |
                                   |                |    | desc (TEXT)      |   |
       +-----------------------+   |                |    | is_recurring(BOL)|   |
       |        income         |   |                +-----------------------+   |
       +-----------------------+   |                                            |
       | PK | id (UUID)        |   |                +-----------------------+   |
       | FK | user_id -------->+   |                |  recurring_expenses   |   |
       |    | amount (NUMERIC) |   |                +-----------------------+   |
       |    | date (DATE)      |   |                | PK | id (UUID)        |   |
       |    | source (VARCHAR) |   +--------------->| FK | user_id          |   |
       +-----------------------+                    | FK | category_id ---->+   |
                                                    |    | amount (NUMERIC) |   |
                                                    |    | frequency (STR)  |   |
                                                    |    | next_run (DATE)  |   |
                                                    +-----------------------+
```

### Table Definitions

#### 1. `users` Table
*Primary profile entity.*
- `id`: `UUID` (Primary Key, Default: `uuid_generate_v4()`)
- `email`: `VARCHAR(255)` (Unique, Indexed, Non-Nullable)
- `hashed_password`: `VARCHAR(255)` (Non-Nullable)
- `created_at`: `TIMESTAMP WITH TIME ZONE` (Default: `NOW()`)

#### 2. `categories` Table
*System-wide lookup table.*
- `id`: `SERIAL` (Primary Key)
- `name`: `VARCHAR(100)` (Unique, Non-Nullable)
- `icon_key`: `VARCHAR(50)` (Nullable, e.g., "utensils", "car")
- `color_hex`: `VARCHAR(7)` (Default: "#3B82F6")

#### 3. `expenses` Table
*The primary transaction log.*
- `id`: `UUID` (Primary Key)
- `user_id`: `UUID` (Foreign Key -> `users.id` ON DELETE CASCADE, Indexed)
- `category_id`: `INT` (Foreign Key -> `categories.id` ON DELETE RESTRICT, Indexed)
- `amount`: `NUMERIC(12, 2)` (Non-Nullable) - *Used for precision-critical financial decimals instead of floating-point numbers.*
- `date`: `DATE` (Non-Nullable, Indexed)
- `payment_method`: `VARCHAR(50)` (e.g., "Credit Card", "Cash", "UPI")
- `description`: `TEXT` (Non-Nullable)
- `is_recurring`: `BOOLEAN` (Default: `FALSE`)
- `created_at`: `TIMESTAMP WITH TIME ZONE` (Default: `NOW()`)

#### 4. `budgets` Table
*Stores monthly limit structures.*
- `id`: `UUID` (Primary Key)
- `user_id`: `UUID` (Foreign Key -> `users.id` ON DELETE CASCADE, Indexed)
- `category_id`: `INT` (Foreign Key -> `categories.id` ON DELETE CASCADE, Nullable) - *If null, it represents the overall monthly budget.*
- `amount`: `NUMERIC(12, 2)` (Non-Nullable)
- `month`: `DATE` (Non-Nullable, e.g., "2026-06-01" represents June 2026)

#### 5. `income` Table
*Tracks incoming money streams.*
- `id`: `UUID` (Primary Key)
- `user_id`: `UUID` (Foreign Key -> `users.id` ON DELETE CASCADE, Indexed)
- `amount`: `NUMERIC(12, 2)` (Non-Nullable)
- `date`: `DATE` (Non-Nullable, Indexed)
- `source`: `VARCHAR(100)` (e.g., "Salary", "Freelance")
- `description`: `TEXT` (Nullable)

#### 6. `recurring_expenses` Table
*Tracks billing schedules.*
- `id`: `UUID` (Primary Key)
- `user_id`: `UUID` (Foreign Key -> `users.id` ON DELETE CASCADE, Indexed)
- `category_id`: `INT` (Foreign Key -> `categories.id` ON DELETE SET NULL)
- `amount`: `NUMERIC(12, 2)` (Non-Nullable)
- `frequency`: `VARCHAR(50)` (e.g., "weekly", "monthly", "yearly")
- `start_date`: `DATE` (Non-Nullable)
- `next_run_date`: `DATE` (Non-Nullable, Indexed)
- `description`: `TEXT` (Non-Nullable)

### Database Relationships
- **One User -> Many Expenses/Budgets/Income/Recurring**: Direct parent-child relationships with cascading deletion rules on the user account.
- **One Category -> Many Expenses/Budgets**: Prevent accidental category deletions using SQL `ON DELETE RESTRICT` constraints to protect historical ledger items.

---

## 5. Backend API Design (FastAPI)

All routes require a valid JSON Web Token passed in the HTTP Header: `Authorization: Bearer <JWT_TOKEN>`.

### Module 1: Authentication (`/api/auth`)
- **POST `/api/auth/register`**
  - *Purpose*: Register a new user.
  - *Auth Required*: No.
  - *Request Body*: `{"email": "student@college.edu", "password": "SecurePassword123"}`
  - *Response*: `{"id": "uuid-string", "email": "student@college.edu", "created_at": "2026-06-25T14:00:00Z"}`
- **POST `/api/auth/token`**
  - *Purpose*: Exchange credentials for a JWT token.
  - *Auth Required*: No.
  - *Request Body*: Form URL encoded: `username=student@college.edu&password=SecurePassword123`
  - *Response*: `{"access_token": "eyJhbG...", "token_type": "bearer"}`
- **GET `/api/auth/me`**
  - *Purpose*: Get current logged-in user profile.
  - *Auth Required*: Yes.
  - *Response*: `{"id": "uuid-string", "email": "student@college.edu"}`

### Module 2: Expenses (`/api/expenses`)
- **POST `/api/expenses`**
  - *Purpose*: Create a new expense.
  - *Auth Required*: Yes.
  - *Request Body*: 
    ```json
    {
      "amount": 42.50,
      "date": "2026-06-25",
      "payment_method": "Credit Card",
      "description": "Starbucks and bagels",
      "category_id": null 
    }
    ```
    *(If `category_id` is null, the AI model automatically categorizes it).*
  - *Response*: 
    ```json
    {
      "id": "exp-uuid",
      "amount": 42.50,
      "date": "2026-06-25",
      "payment_method": "Credit Card",
      "description": "Starbucks and bagels",
      "category_id": 3,
      "is_ai_predicted": true,
      "detected_anomaly": false
    }
    ```
- **GET `/api/expenses`**
  - *Purpose*: Retrieve a paginated, filtered list of user expenses.
  - *Auth Required*: Yes.
  - *Query Params*: `page=1`, `limit=20`, `category_id=3`, `start_date=2026-06-01`, `end_date=2026-06-30`, `search=bagel`
  - *Response*: `{"total": 1, "page": 1, "limit": 20, "data": [...]}`
- **GET `/api/expenses/{id}`**
  - *Purpose*: Retrieve a single expense.
  - *Auth Required*: Yes.
- **PUT `/api/expenses/{id}`**
  - *Purpose*: Update an expense.
  - *Auth Required*: Yes.
- **DELETE `/api/expenses/{id}`**
  - *Purpose*: Delete an expense.
  - *Auth Required*: Yes.

### Module 3: Budgets (`/api/budgets`)
- **POST `/api/budgets`**
  - *Purpose*: Set a monthly budget limit.
  - *Auth Required*: Yes.
  - *Request Body*: `{"category_id": 3, "amount": 200.00, "month": "2026-06-01"}`
  - *Response*: `{"id": "budget-uuid", "category_id": 3, "amount": 200.00, "month": "2026-06-01"}`
- **GET `/api/budgets/status`**
  - *Purpose*: Fetch current-month budgets with actual spending totals.
  - *Auth Required*: Yes.
  - *Response*:
    ```json
    [
      {
        "category_id": 3,
        "category_name": "Food & Dining",
        "limit": 200.00,
        "spent": 142.50,
        "percentage_used": 71.25
      }
    ]
    ```

### Module 4: Dashboard & Analytics (`/api/analytics`)
- **GET `/api/analytics/summary`**
  - *Purpose*: Get basic high-level summary cards.
  - *Auth Required*: Yes.
  - *Response*: `{"total_spent": 1245.80, "total_income": 3000.00, "net_savings": 1754.20, "budget_burn_rate": 41.5}`
- **GET `/api/analytics/categories`**
  - *Purpose*: Pie chart distribution aggregations.
  - *Response*: `[{"category": "Food", "value": 340.20, "color": "#EF4444"}, ...]`
- **GET `/api/analytics/trends`**
  - *Purpose*: Monthly trend charting arrays.
  - *Response*: `[{"date": "2026-06-01", "expenses": 12.00, "income": 0.00}, ...]`

### Module 5: AI Insights (`/api/ai`)
- **POST `/api/ai/classify-text`**
  - *Purpose*: Dry-run classification of description text.
  - *Request Body*: `{"text": "Spotify premium subscription"}`
  - *Response*: `{"predicted_category_id": 5, "confidence": 0.98}`
- **GET `/api/ai/forecast`**
  - *Purpose*: Project total spending for the end of the current month.
  - *Response*: `{"current_spend": 1245.80, "projected_spend": 1620.50, "is_over_budget": true, "confidence_interval": [1510.00, 1730.00]}`
- **GET `/api/ai/insights`**
  - *Purpose*: Generate real-time heuristic alerts.
  - *Response*:
    ```json
    [
      {"type": "warning", "message": "Your Food spending is pacing 25% faster than last month."},
      {"type": "info", "message": "74% of your shopping expenses occur between Friday afternoon and Sunday evening."}
    ]
    ```

---

## 6. Frontend Page & Component Plan

### Page-by-Page Layout

#### 1. Landing Page
- **Purpose**: Brand introduction, value propositions (features, tech showcase), and clean navigation buttons to Register/Login.
- **UI Elements**: High-fidelity hero banner, system architecture infographic, and "Try it out" call-to-actions.

#### 2. Auth Pages (Register / Login)
- **Purpose**: Authenticate user profiles.
- **UI Elements**: Focused login and registration forms featuring responsive input states, error validation warnings, and smooth redirect transitions.

#### 3. Main Dashboard Page
- **Purpose**: The central command center of the application.
- **UI Elements**:
  - Top row containing three dynamic summary statistic cards (Income, Expenses, Savings).
  - A main dashboard split layout: left side shows a Monthly Spend Line Chart (Recharts), right side displays a Category Breakdown Doughnut Chart.
  - Bottom row showing a Budget Alerts sidebar alongside a Recent Transactions table.

#### 4. Expenses Ledger Page
- **Purpose**: Comprehensive tabular transaction tracking.
- **UI Elements**:
  - Top control panel containing a search input, category filter drop-down, and date selector.
  - Interactive table displaying Date, Description, Category, Payment Method, and Amount columns.
  - Clickable table actions supporting edit modals or delete confirmations.

#### 5. Modal — Add/Edit Expense
- **Purpose**: Easy transaction input.
- **UI Elements**: Form fields for Amount, Date, and Description. A dynamic Category field featuring a **"Sparkle" icon** indicates that the AI auto-categorization engine is listening.

#### 6. Budgets Console Page
- **Purpose**: Configure monthly spending limits.
- **UI Elements**: Simple grid layout of category budget cards displaying active progress bars, percent usage badges, and a "Set Budget" input form.

#### 7. Smart AI Insights Page
- **Purpose**: Highlights interesting anomalies and spending patterns.
- **UI Elements**: Clean list layout of intelligence cards grouped by level (Danger, Warning, Success) highlighting specific actionable patterns.

### Reusable Components
- **`Layout/Sidebar`**: Responsive navigation dock containing active routing states.
- **`UI/StatCard`**: Reusable statistic container featuring custom icon slots, numeric values, and trend badges.
- **`UI/ProgressBar`**: Dynamic progress indicator that automatically transitions colors from green to amber and red as limits are approached.
- **`Charts/ExpenseLineChart`**: Custom configured Recharts wrapper that adjusts gracefully to different screen sizes.

---

## 7. Backend Build Order (FastAPI)

Follow this exact build order to construct a stable and fully verified backend:

```
Step 1: Setup Environment & Dependencies
  └── Step 2: Database Engine & Base Models
        └── Step 3: Users & JWT Authentication
              └── Step 4: Expense, Income & Budget Tables
                    └── Step 5: Core CRUD API Routers
                          └── Step 6: Analytics & Group-by Aggregations
                                └── Step 7: Local ML Services (TF-IDF, Linear Regression)
```

### Detailed Construction Steps

#### Step 1: Environment & Directory Initialization
Create the project files and directory structure. Define standard environment variables in `.env` (excluding active secrets from version control):
- Key file responsibilities: Define project dependency schemas in `requirements.txt` and manage database connections in `app/core/config.py`.
- *Verification*: Verify the setup runs correctly by starting the Uvicorn local dev server.

#### Step 2: SQLAlchemy Core Engine & Migrations
Configure connection pools in `app/db/session.py` to establish database connectivity.
- Key file responsibilities: Define metadata bases in `app/db/base_class.py`. Build model mappings for core database structures.
- *Verification*: Connect to the database via shell or pgAdmin to confirm all tables generate with correct constraints and index structures.

#### Step 3: JWT Security & User Routes
Build the user accounts engine in `app/core/security.py`.
- Key file responsibilities: Set up bcrypt hashing functions. Register login and callback authentication routes inside `app/api/endpoints/auth.py`.
- *Verification*: Test register and token generation routes via the Swagger interactive UI (`/docs`). Verify JWT payloads are generated with correct expiration timestamps.

#### Step 4: Core CRUD API Implementation
Implement basic transactional logic for Expense and Budget schemas inside `app/api/endpoints/expenses.py` and `app/api/endpoints/budgets.py`.
- Key file responsibilities: Enforce strict user isolation policies by requiring that all database queries validate against the authenticated `current_user` ID.
- *Verification*: Run extensive validation tests for creating, editing, and deleting expenses. Confirm that non-authenticated requests are blocked.

#### Step 5: Aggregation Analytics Routers
Write optimized SQL queries in `app/services/analytics.py` using SQLAlchemy `func.sum` and `group_by` statements to aggregate category expenses.
- Key file responsibilities: Implement trend-line dataset queries that return day-by-day totals for the active month.
- *Verification*: Query the endpoint and confirm the response matches aggregated transaction totals.

#### Step 6: Local Machine Learning Services
Build the offline Scikit-Learn training pipelines in `app/services/ml_classifier.py` and statistical projections inside `app/services/ml_forecaster.py`.
- Key file responsibilities: Load pre-trained serialization artifacts (`.joblib` format) into the FastAPI application on startup.
- *Verification*: Send test queries containing descriptions (e.g., "Uber ride to office") and verify that correct category IDs are assigned.

---

## 8. Frontend Build Order (React)

Build the user interface in a structured, progressive sequence to avoid integration headaches:

```
Step 1: Scaffolding, Routing, & Global CSS
  └── Step 2: Axios Client & Authentication States
        └── Step 3: Base Layout & Sidebar Navigation
              └── Step 4: Transaction Ledger & Filtering UI
                    └── Step 5: Add/Edit Expense AI Input Modals
                          └── Step 6: Recharts Analytical Dashboard
                                └── Step 7: Smart Insights Cards & UI Polish
```

### Detailed Construction Steps

#### Step 1: Client Scaffolding & Routing
Initialize the frontend build using Vite and React.
- Key file responsibilities: Set up Tailwind imports in `src/index.css`. Build routing layouts using `react-router` inside `src/App.tsx`.
- *Verification*: Launch the Vite development server and verify navigation operates smoothly.

#### Step 2: Authentication Context
Create the authentication wrapper in `src/context/AuthContext.tsx`.
- Key file responsibilities: Implement unified API request patterns in `src/services/api.ts` to attach authorization headers dynamically.
- *Verification*: Test register and login form submissions and verify authentication state persists correctly in browser memory.

#### Step 3: Workspace Grid Layout
Build cohesive workspace containers including responsive sidebars and headers.
- Key file responsibilities: Ensure layouts adapt smoothly to smaller viewports.
- *Verification*: Test layouts on multiple screen dimensions to verify spacing is responsive.

#### Step 4: Expense Ledger UI
Build the main tabular display inside `src/pages/Expenses.tsx`.
- Key file responsibilities: Implement interactive search, category selection filters, and table pagination mechanics.
- *Verification*: Confirm list states refresh correctly when modifying filters.

#### Step 5: Modals with AI Integrations
Build inputs for managing transactions in `src/components/ExpenseModal.tsx`.
- Key file responsibilities: Implement logic that triggers predictions when a user types in a description.
- *Verification*: Type "dinner" and verify the category select is updated automatically.

#### Step 6: Recharts Analytics Dashboards
Connect the main pages to your backend services in `src/pages/Dashboard.tsx`.
- Key file responsibilities: Render interactive line charts and responsive category distributions.
- *Verification*: Match visual charts against database values to verify accuracy.

---

## 9. AI / ML Implementation Plan

This project uses classic, robust, and highly interpretable machine learning models. By training these locally, we avoid cold-start latencies and external API fees, making the project highly impressive to hiring managers.

### 1. Expense Categorization Model
- **Model Choice**: `TF-IDF Vectorizer + Logistic Regression`.
- **Why**: High-speed inference, extremely low memory footprint, and highly accurate for text classification tasks when trained on clean datasets.
- **Dataset Structure (JSON File used for training: `training_data.json`)**:
  ```json
  [
    {"text": "Uber ride home", "category": "Transport"},
    {"text": "Lyft office commute", "category": "Transport"},
    {"text": "Starbucks cold brew", "category": "Food & Dining"},
    {"text": "Dominos pepperoni pizza", "category": "Food & Dining"},
    {"text": "Netflix premium plan monthly", "category": "Entertainment"},
    {"text": "Steam game purchase", "category": "Entertainment"},
    {"text": "Target grocery milk", "category": "Shopping"}
  ]
  ```
- **Training Pipeline Script (`ml/train_classifier.py`)**:
  ```python
  import pandas as pd
  from sklearn.feature_extraction.text import TfidfVectorizer
  from sklearn.linear_model import LogisticRegression
  from sklearn.pipeline import Pipeline
  import joblib

  def train_and_save_model():
      # Load training data
      df = pd.read_json("ml/training_data.json")
      
      # Build Pipeline
      pipeline = Pipeline([
          ('tfidf', TfidfVectorizer(ngram_range=(1, 2), stop_words='english', lowercase=True)),
          ('clf', LogisticRegression(C=1.0, max_iter=200))
      ])
      
      # Fit model
      pipeline.fit(df['text'], df['category'])
      
      # Export to file
      joblib.dump(pipeline, "app/static/models/category_model.joblib")
      print("Model trained and saved successfully.")
  ```
- **FastAPI Integration Service (`app/services/classifier.py`)**:
  ```python
  import joblib
  import os

  class CategoryClassifier:
      def __init__(self):
          model_path = "app/static/models/category_model.joblib"
          if os.path.exists(model_path):
              self.model = joblib.load(model_path)
          else:
              self.model = None

      def predict_category(self, description_text: str) -> str:
          if not self.model:
              return "Miscellaneous"
          try:
              prediction = self.model.predict([description_text])
              return prediction[0]
          except Exception:
              return "Miscellaneous"

  classifier_service = CategoryClassifier()
  ```

---

### 2. Monthly Spending Predictor
- **Target Variable**: Total anticipated expenditure at the end of the current billing month.
- **Features Used**:
  - `days_passed`: (e.g., Day 12 of 30)
  - `current_cumulative_spend`: Total amount spent so far.
  - `run_rate_per_day`: `current_cumulative_spend / days_passed`
  - `historical_average_month_spend`: Total average spending of previous 3 months.
- **Model Choice**: `Linear Regression / Trend Projection`.
- **Implementation (Projecting future spending based on current month progress)**:
  ```python
  def predict_month_end_spend(current_spend: float, day_of_month: int, total_days: int, historical_avg: float) -> float:
      if day_of_month == 0:
          return historical_avg
      
      # Proportional projection
      run_rate_projection = (current_spend / day_of_month) * total_days
      
      # Weighted blend: 60% current run rate pacing, 40% historical average baseline
      weighted_prediction = (0.6 * run_rate_projection) + (0.4 * historical_avg)
      return round(weighted_prediction, 2)
  ```

---

### 3. Anomaly Detection
- **Definition of Anomaly**: A transaction amount that deviates significantly from a user's spending habits for that specific category.
- **Model Choice**: `Statistical Standard Score (Z-Score)`.
- **How it Works**:
  1. Retrieve all transactions in the target category for the last 6 months.
  2. Compute Mean ($\mu$) and Standard Deviation ($\sigma$) of the transaction amounts.
  3. For any new transaction amount ($x$):
     $$Z = \frac{x - \mu}{\sigma}$$
  4. If $|Z| > 2.5$ (or standard threshold), flag as anomalous.
- **In-App Warning**: Surfaced in the ledger UI with an amber exclamation icon ("Unusually high Shopping expense").

---

### 4. Dynamic Heuristic Insights Engine
- **Strategy**: Rule-based analytics generated on demand. This approach is highly reliable and provides consistent value without the hallucination risks of generative models.
- **Key Heuristics**:
  - *Heuristic 1*: "Weekend Surge" -> Check if more than 60% of discretionary spending (Shopping, Food) occurs on Friday, Saturday, or Sunday.
  - *Heuristic 2*: "Subscription Burn" -> Sum all active recurring subscriptions and compare it to total monthly income.
  - *Heuristic 3*: "Pacing Alert" -> Compare total current category spend to the budget limit. If day-of-month progress is at 40% but budget usage is at 80%, flag as "Overpacing."

---

## 10. End-to-End App Workflow

Below is the lifecycle of a typical user session when adding a new expense:

```
[React App]
  │ (User types "swiggy breakfast" for $22.50)
  ▼
[API POST /api/expenses] (Authorization: Bearer <JWT>)
  │
  ├─► [FastAPI Router]
  │     │ (Validates JWT, looks up current user account)
  │     ▼
  ├─► [AI Categorization Service]
  │     │ (Processes "swiggy breakfast" through the loaded TF-IDF Pipeline)
  │     │ (Predicts category is "Food & Dining")
  │     ▼
  ├─► [Anomaly Detection Engine]
  │     │ (Queries historical food spending mean and standard dev for user)
  │     │ (Checks if $22.50 is an anomaly -> returns False)
  │     ▼
  ├─► [PostgreSQL Database]
  │     │ (Saves transaction with category_id, is_ai_predicted=True, anomaly=False)
  │     ▼
  ├─► [Budget Enforcer Service]
  │     │ (Checks current food spending total against limit)
  │     │ (If spend > 80% limit, generates a high-priority budget warning)
  │     ▼
  └─► [FastAPI Response JSON]
        │
        ▼
[React App State Updates]
  │ (Recharts dashboard re-renders with new transaction)
  │ (The user's food budget progress bar increments)
  │ (A Toast message appears: "Expense added and auto-categorized into Food!")
```

---

## 11. Final Project Roadmap

### Phase 1 — Planning & Setup (Week 1)
- **Objective**: Establish development environments, configure the database connection, and verify structural routing.
- **Deliverables**: `.env` configuration file, PostgreSQL connection schemas, and basic React layout grids with sidebar routing.
- **Common Mistake**: Starting without proper database constraints. *Fix: Always define relational fields with explicit Cascade rules and indexes from day one.*

### Phase 2 — Core Backend Engine (Week 2)
- **Objective**: Secure user authentication systems and implement standard CRUD routers.
- **Deliverables**: Secure endpoints for managing users, tracking expenses, and setting budgets.
- **Common Mistake**: Neglecting route security. *Fix: Implement robust authentication helper functions to protect all private endpoints.*

### Phase 3 — Core Frontend Pages (Week 3)
- **Objective**: Construct responsive data input views.
- **Deliverables**: Pages for user login, displaying the transaction ledger, and inputting expenses.
- **Common Mistake**: Handling complex forms in a single state variable. *Fix: Build modular forms and implement local validation checks before submitting data.*

### Phase 4 — Data Visualizations & Analytics (Week 4)
- **Objective**: Integrate interactive charts.
- **Deliverables**: Integrated line charts showing monthly trends and pie charts representing category spending distributions.
- **Common Mistake**: Fetching large amounts of unaggregated transaction data. *Fix: Let PostgreSQL handle the heavy lifting by performing aggregated group-by queries on the backend.*

### Phase 5 — AI Intelligence Layer (Week 5)
- **Objective**: Embed local machine learning models into the backend.
- **Deliverables**: Auto-categorization pipelines and statistical month-end spending predictors.
- **Common Mistake**: Running model training scripts directly inside the HTTP request loop. *Fix: Keep transaction creation fast by loading pre-trained model artifacts (`.joblib`) on application startup.*

### Phase 6 — Polish & Deployment (Week 6)
- **Objective**: Refine user interactions, handle errors gracefully, and deploy to hosting providers.
- **Deliverables**: Production app deployed on Render/Railway/Vercel, complete project README, and bullet points ready for your resume.
- **Common Mistake**: Leaving development credentials exposed. *Fix: Double-check that all environment variables are correctly configured in production settings.*

---

## 12. Final Recommended Scope

### MUST BUILD (Version 1 Core)
- **Robust User Authentication**: Secure login flow with secure JWT management.
- **Clean Expense CRUD Ledger**: Standard ledger supporting searches, category filtering, and item deletion.
- **Dynamic Category Breakdowns**: Clear visualizations using responsive Doughnut/Pie Charts.
- **Local AI Auto-Categorization Model**: Real-time category predictions using a locally trained TF-IDF classifier.
- **Budget Alerts**: Visual status indicators (e.g., changing progress bar colors from green to red).

### GOOD TO ADD (Version 1.5 Polish)
- **Income Tracker**: Compute and display net savings metrics.
- **Recurring Expenses Scheduler**: Automate entries for recurring monthly bills.
- **Anomaly Detection Alerts**: Flag unusually high transactions in the UI ledger.
- **Smart Pacing Insights**: Heuristics warning users if they are spending too fast for the current day of the month.

### SKIP FOR NOW (Version 2 Future Scope)
- **Plaid Bank Sync**: Avoid complex bank integrations early on. Stick to CSV/Manual inputs.
- **Receipt Optical Character Recognition (OCR)**: Scans can be slow and computationally heavy. Keep this as a future enhancement.
- **Generative Chatbots**: Don't waste resources building complex chat boxes. Focus on polished, structured dashboards first.

---

## 13. Common Mistakes to Avoid

1. **Relational Database N+1 Query Problems**:
   - *Problem*: Querying a list of expenses and calling database lookups for every individual category item in a loop.
   - *Fix*: Use SQL joins or SQLAlchemy’s `.joinedload(Expense.category)` to fetch all required relational details in a single query.
2. **Exposing Secrets in Version Control**:
   - *Problem*: Committing API secrets or JWT keys directly to GitHub.
   - *Fix*: Always read configuration values from environmental variables and keep `.env` files blacklisted in `.gitignore`.
3. **Blocking Python Event Loops with ML Computations**:
   - *Problem*: Re-training models or running intensive processes during HTTP request-response cycles.
   - *Fix*: Handle model training tasks in independent background processes, and run predictions on pre-loaded static models in memory.
4. **Poor handling of timezone differences**:
   - *Problem*: Expenses shift days depending on where the user is accessing the app.
   - *Fix*: Standardize database timestamps to UTC and display dates in the user's local timezone.

---

## 14. Suggested Repository Structure

To maintain a clean division of responsibilities, organize the project in a monorepo structure:

```
personal-finance-assistant/
├── .gitignore
├── README.md
├── docker-compose.yml
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── run.sh
│   └── app/
│       ├── __init__.py
│       ├── main.py
│       ├── api/
│       │   ├── deps.py
│       │   └── endpoints/
│       │       ├── auth.py
│       │       ├── expenses.py
│       │       └── budgets.py
│       ├── core/
│       │   ├── config.py
│       │   └── security.py
│       ├── db/
│       │   ├── base_class.py
│       │   └── session.py
│       ├── models/
│       │   ├── user.py
│       │   ├── expense.py
│       │   └── budget.py
│       ├── schemas/
│       │   ├── user.py
│       │   ├── expense.py
│       │   └── budget.py
│       └── services/
│           ├── classifier.py
│           └── forecaster.py
├── frontend/
│   ├── package.json
│   ├── vite.config.ts
│   ├── index.html
│   ├── src/
│   │   ├── main.tsx
│   │   ├── App.tsx
│   │   ├── index.css
│   │   ├── components/
│   │   │   ├── Sidebar.tsx
│   │   │   └── ExpenseModal.tsx
│   │   ├── context/
│   │   │   └── AuthContext.tsx
│   │   ├── pages/
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Expenses.tsx
│   │   │   └── Budgets.tsx
│   │   └── services/
│   │       └── api.ts
└── ml_pipeline/
    ├── train_classifier.py
    └── training_data.json
```

---

## 15. Suggested Resume Bullet Points

Craft your resume bullet points using the **STAR method (Situation, Task, Action, Result)** or Google's **X-Y-Z formula**: *"Accomplished [X] as measured by [Y], by doing [Z]"*.

### Backend / Engineering Focus:
- "Designed and built a modular full-stack personal finance application using **FastAPI**, **React**, and **PostgreSQL** that successfully processed over 10,000 mocked ledger items with query latencies below 50ms."
- "Optimized relational database interactions by implementing compound indexes and SQLAlchemy **joined loading (joinedload)** strategies, reducing transaction load times on the frontend dashboard by 40%."
- "Engineered a secure, JWT-based user authentication system using **bcrypt** password encryption, establishing secure authorization boundaries across all CRUD endpoints."

### AI & Machine Learning Focus:
- "Integrated an offline **Scikit-Learn text classification pipeline** (TF-IDF + Logistic Regression) inside an async backend, automating description categorization with a **94% cross-validation accuracy**."
- "Built a time-series forecast engine utilizing a weighted linear regression model to predict user month-end cumulative spending, maintaining a mean absolute error of less than 4.5%."
- "Constructed a real-time unsupervised anomaly detection system using **statistical Z-scores** to automatically flag transaction patterns deviating from the category baseline by more than 2.5 standard deviations."
