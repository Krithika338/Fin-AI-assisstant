/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  email: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  userId: string;
  amount: number;
  category: string;
  date: string;
  paymentMethod: string;
  description: string;
  isRecurring: boolean;
  isAiPredicted?: boolean;
  detectedAnomaly?: boolean;
  anomalyReason?: string;
  createdAt: string;
}

export interface Budget {
  id: string;
  userId: string;
  category: string; // If 'All', it's the global budget
  amount: number;
  month: string; // YYYY-MM format
}

export interface Income {
  id: string;
  userId: string;
  amount: number;
  date: string;
  source: string;
  description?: string;
  createdAt: string;
}

export interface RecurringExpense {
  id: string;
  userId: string;
  amount: number;
  category: string;
  frequency: 'weekly' | 'monthly' | 'yearly';
  startDate: string;
  nextRunDate: string;
  description: string;
}

export interface AIInsight {
  id: string;
  type: 'danger' | 'warning' | 'success' | 'info';
  message: string;
  title: string;
}

export interface SpendingForecast {
  currentSpend: number;
  projectedSpend: number;
  isOverBudget: boolean;
  confidenceInterval: [number, number];
  aiExplanation?: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
}
