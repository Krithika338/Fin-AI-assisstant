/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DollarSign, Plus, Trash2, ArrowDownLeft, Calendar } from 'lucide-react';

interface IncomeProps {
  incomes: any[];
  onAddIncome: (amount: number, date: string, source: string, description: string) => void;
  onDeleteIncome: (id: string) => void;
  currency: 'USD' | 'INR';
  exchangeRate: number;
}

export default function Income({ incomes, onAddIncome, onDeleteIncome, currency, exchangeRate }: IncomeProps) {
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().substring(0, 10));
  const [source, setSource] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currencySymbol = currency === 'INR' ? '₹' : '$';

  const formatAmount = (usdAmount: number) => {
    const amount = currency === 'INR' ? usdAmount * exchangeRate : usdAmount;
    return `${currencySymbol}${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (!source || isNaN(val) || val <= 0 || !date) return;

    setIsSubmitting(true);
    try {
      // If active currency is INR, convert the user's input credit from INR to USD for API storage
      const usdValue = currency === 'INR' ? val / exchangeRate : val;
      await onAddIncome(usdValue, date, source, description);
      setAmount('');
      setSource('');
      setDescription('');
    } finally {
      setIsSubmitting(false);
    }
  };

  const formattedDate = (dateStr: string) => {
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return `${months[parseInt(parts[1], 10) - 1]} ${parts[2]}, ${parts[0]}`;
      }
      return dateStr;
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="income_view">
      
      {/* Left side: Add income stream */}
      <div className="lg:col-span-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-100 h-fit">
        <h3 className="font-bold text-slate-800 text-sm mb-1.5 flex items-center gap-1.5">
          <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
          <span>Record Cash Inflow</span>
        </h3>
        <p className="text-xs text-slate-400 mb-6">Track wages, stipends, and gig-work credits to calculate net cash flow margins</p>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Source Stream
            </label>
            <input
              type="text"
              value={source}
              onChange={(e) => setSource(e.target.value)}
              placeholder="e.g. Software Internship Wages"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all font-semibold text-slate-700"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Amount ({currencySymbol})
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-slate-400 text-sm font-bold">{currencySymbol}</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                min="1"
                step="any"
                className="w-full pl-7.5 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Receipt Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Memo Details (Optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Notes on project scope..."
              rows={2}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting || !amount || !source}
            className="w-full py-3 bg-emerald-600 text-white font-bold rounded-xl text-xs hover:bg-emerald-700 transition-colors shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50 mt-2"
          >
            {isSubmitting ? (
              <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5" />
                <span>Log Cash Credit</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Right side: Income history list */}
      <div className="lg:col-span-8 flex flex-col gap-5">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div>
            <h3 className="font-bold text-slate-800 text-sm">Receipt Ledger</h3>
            <p className="text-xs text-slate-400 mb-6">Historical record of all verified cash influx logs</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Source Stream</th>
                  <th className="py-3 px-4">Memo</th>
                  <th className="py-3 px-4 text-right">Credit Amount</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-xs">
                {incomes && incomes.length > 0 ? (
                  incomes.map((inc) => (
                    <tr key={inc.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="py-3.5 px-4 font-medium text-slate-500 whitespace-nowrap">
                        {formattedDate(inc.date)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-800">
                        {inc.source}
                      </td>
                      <td className="py-3.5 px-4 text-slate-500 italic max-w-[150px] truncate" title={inc.description}>
                        {inc.description || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-emerald-600 whitespace-nowrap">
                        +{formatAmount(inc.amount)}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => {
                            if (confirm('Delete this income record?')) {
                              onDeleteIncome(inc.id);
                            }
                          }}
                          className="p-1.5 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                          title="Delete Credit"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-400">
                      No verified income influx logs present.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  );
}
