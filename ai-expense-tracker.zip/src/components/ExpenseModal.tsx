/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, Sparkles, AlertTriangle } from 'lucide-react';
import { Expense } from '../types';

interface ExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: any) => Promise<void>;
  editExpense: Expense | null;
  currency: 'USD' | 'INR';
  exchangeRate: number;
}

export default function ExpenseModal({ isOpen, onClose, onSave, editExpense, currency, exchangeRate }: ExpenseModalProps) {
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().substring(0, 10));
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Auto (AI)');
  const [paymentMethod, setPaymentMethod] = useState('Debit Card');
  const [isRecurring, setIsRecurring] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  const currencySymbol = currency === 'INR' ? '₹' : '$';

  const categories = [
    'Auto (AI)',
    'Food & Dining',
    'Transport & Travel',
    'Shopping',
    'Entertainment & Subscriptions',
    'Utilities & Bills',
    'Miscellaneous',
  ];

  const paymentMethods = ['Debit Card', 'Credit Card', 'UPI', 'Cash', 'Bank Transfer'];

  // Sync state if editing
  useEffect(() => {
    if (editExpense) {
      const displayAmount = currency === 'INR' ? editExpense.amount * exchangeRate : editExpense.amount;
      setAmount(displayAmount.toFixed(2));
      setDate(editExpense.date);
      setDescription(editExpense.description);
      setCategory(editExpense.category);
      setPaymentMethod(editExpense.paymentMethod);
      setIsRecurring(editExpense.isRecurring);
    } else {
      setAmount('');
      setDate(new Date().toISOString().substring(0, 10));
      setDescription('');
      setCategory('Auto (AI)');
      setPaymentMethod('Debit Card');
      setIsRecurring(false);
    }
    setError('');
  }, [editExpense, isOpen, currency, exchangeRate]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Amount must be a positive number');
      return;
    }

    if (!description.trim()) {
      setError('Description is required');
      return;
    }

    setIsSaving(true);
    try {
      const usdAmount = currency === 'INR' ? parsedAmount / exchangeRate : parsedAmount;
      await onSave({
        id: editExpense?.id,
        amount: usdAmount,
        date,
        description: description.trim(),
        category,
        paymentMethod,
        isRecurring,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save expense. Please verify connection.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose}></div>

      {/* Modal Container */}
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-lg border border-slate-100 p-6 flex flex-col gap-5 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex justify-between items-center pb-2 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-800 text-sm">
              {editExpense ? 'Update Expense Details' : 'Record New Spend'}
            </h3>
            <p className="text-[11px] text-slate-400">
              {editExpense ? 'Modify details of this historical transaction' : 'Manually input transaction details'}
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-700 rounded-lg transition-colors">
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-[11px] text-red-600 flex items-start gap-1.5">
            <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          
          {/* Description */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Description / Description
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Swiggy delivery pizza with buddies"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all font-semibold text-slate-700"
            />
          </div>

          {/* Amount and Date row */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Amount ({currencySymbol})
              </label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                min="0.01"
                step="any"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all font-bold text-slate-700"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Expense Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all font-medium text-slate-700"
              />
            </div>
          </div>

          {/* Category Selector */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center justify-between">
              <span>Expense Category</span>
              {category === 'Auto (AI)' && (
                <span className="flex items-center gap-1 text-[9px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded-lg border border-blue-100">
                  <Sparkles className="w-2.5 h-2.5 animate-pulse" />
                  <span>AI NLP Categorize Enabled</span>
                </span>
              )}
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all text-slate-700"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Payment Method
            </label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all text-slate-700"
            >
              {paymentMethods.map((pm) => (
                <option key={pm} value={pm}>
                  {pm}
                </option>
              ))}
            </select>
          </div>

          {/* Recurring Expense checkbox */}
          <div className="flex items-center gap-2 py-1">
            <input
              type="checkbox"
              id="is_rec_check"
              checked={isRecurring}
              onChange={(e) => setIsRecurring(e.target.checked)}
              className="w-4 h-4 accent-blue-600 border-slate-300 rounded cursor-pointer"
            />
            <label htmlFor="is_rec_check" className="text-xs text-slate-600 font-medium select-none cursor-pointer">
              This is a recurring monthly subscription bill (e.g. Rent, Netflix)
            </label>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3.5 pt-4 border-t border-slate-100 mt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving}
              className="px-4 py-2 bg-slate-100 text-slate-500 rounded-xl text-xs font-bold hover:bg-slate-200 hover:text-slate-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {isSaving ? (
                <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <span>{editExpense ? 'Update Log' : 'Save Log'}</span>
              )}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}
