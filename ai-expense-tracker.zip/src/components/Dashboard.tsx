/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';
import { ArrowUpRight, TrendingUp, Sparkles, CreditCard, Calendar, CheckCircle2, AlertTriangle, ArrowDownLeft } from 'lucide-react';
import { Expense, Budget } from '../types';

interface DashboardProps {
  expenses: Expense[];
  budgets: any[];
  summary: {
    totalSpent: number;
    totalIncome: number;
    netSavings: number;
    budgetBurnRate: number;
    budgetLimit: number;
  };
  categoriesBreakdown: { category: string; value: number; color: string }[];
  trends: { date: string; expenses: number; income: number }[];
  forecast: {
    currentSpend: number;
    projectedSpend: number;
    isOverBudget: boolean;
    confidenceInterval: [number, number];
    aiExplanation?: string;
  };
  insights: any[];
  onNavigate: (tab: string) => void;
  onOpenModal: (type: 'expense' | 'budget' | 'income') => void;
  currency: 'USD' | 'INR';
  exchangeRate: number;
}

export default function Dashboard({
  expenses,
  budgets,
  summary,
  categoriesBreakdown,
  trends,
  forecast,
  insights,
  onNavigate,
  onOpenModal,
  currency,
  exchangeRate,
}: DashboardProps) {

  const currencySymbol = currency === 'INR' ? '₹' : '$';

  const formatAmount = (usdAmount: number) => {
    const amount = currency === 'INR' ? usdAmount * exchangeRate : usdAmount;
    return `${currencySymbol}${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatAmountNoDecimals = (usdAmount: number) => {
    const amount = currency === 'INR' ? usdAmount * exchangeRate : usdAmount;
    return `${currencySymbol}${amount.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  };

  // Convert chart metrics arrays to local currency
  const displayTrends = (trends || []).map(t => ({
    ...t,
    expenses: currency === 'INR' ? t.expenses * exchangeRate : t.expenses,
    income: currency === 'INR' ? t.income * exchangeRate : t.income,
  }));

  const displayCategories = (categoriesBreakdown || []).map(c => ({
    ...c,
    value: currency === 'INR' ? c.value * exchangeRate : c.value,
  }));

  // Simple category icons helper
  const getCategoryColorClass = (category: string) => {
    switch (category) {
      case 'Food & Dining': return 'bg-blue-100 text-blue-600';
      case 'Transport & Travel': return 'bg-emerald-100 text-emerald-600';
      case 'Shopping': return 'bg-amber-100 text-amber-600';
      case 'Entertainment & Subscriptions': return 'bg-pink-100 text-pink-600';
      case 'Utilities & Bills': return 'bg-purple-100 text-purple-600';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  const getCategoryAbbr = (category: string) => {
    switch (category) {
      case 'Food & Dining': return 'F';
      case 'Transport & Travel': return 'T';
      case 'Shopping': return 'S';
      case 'Entertainment & Subscriptions': return 'E';
      case 'Utilities & Bills': return 'U';
      default: return 'M';
    }
  };

  const formattedDate = (dateStr: string) => {
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const monthIndex = parseInt(parts[1], 10) - 1;
        return `${months[monthIndex]} ${parts[2]}`;
      }
      return dateStr;
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="flex flex-col gap-6" id="dashboard_view">
      {/* Top 3 Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Total Spending Card */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100" id="card_total_spend">
          <p className="text-xs font-bold text-slate-400 uppercase mb-1.5 tracking-wider">Monthly Spending</p>
          <div className="flex items-baseline gap-2">
            <h2 className="text-2xl font-bold text-slate-800">{formatAmount(summary.totalSpent)}</h2>
            <span className="text-xs text-slate-400 font-normal">this month</span>
          </div>
          <div className="mt-3 flex items-center gap-1.5">
            <span className="text-xs text-red-500 font-semibold bg-red-50 px-2 py-0.5 rounded-lg flex items-center gap-0.5">
              <ArrowUpRight className="w-3 h-3" /> +12%
            </span>
            <span className="text-[10px] text-slate-400">vs historical baseline</span>
          </div>
        </div>

        {/* Active Budget Progress Card */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100" id="card_active_budget">
          <p className="text-xs font-bold text-slate-400 uppercase mb-1.5 tracking-wider">Active Budget Pacing</p>
          <div className="flex items-baseline justify-between">
            <h2 className="text-2xl font-bold text-slate-800">
              {formatAmountNoDecimals(summary.totalSpent)}
              <span className="text-slate-400 text-sm font-normal"> / {formatAmountNoDecimals(summary.budgetLimit)}</span>
            </h2>
            <span className="text-[11px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-lg">
              {summary.budgetBurnRate}%
            </span>
          </div>
          {/* Progress bar */}
          <div className="mt-4 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                summary.budgetBurnRate > 90 ? 'bg-red-500' : summary.budgetBurnRate > 75 ? 'bg-amber-500' : 'bg-blue-600'
              }`}
              style={{ width: `${Math.min(100, summary.budgetBurnRate)}%` }}
            ></div>
          </div>
          <p className="text-[10px] text-slate-400 mt-2">
            {summary.budgetBurnRate >= 100 ? 'Budget exceeded!' : `${100 - Math.round(summary.budgetBurnRate)}% remaining capacity`}
          </p>
        </div>

        {/* Predictive AI End-of-Month Forecast Card */}
        <div className="bg-blue-600 p-5 rounded-2xl shadow-sm text-white flex flex-col justify-between" id="card_ai_forecast">
          <div>
            <div className="flex justify-between items-center mb-1">
              <p className="text-xs font-bold opacity-80 uppercase tracking-wider">Estimated Month End</p>
              <div className="flex items-center gap-1 bg-white/15 px-2 py-0.5 rounded-lg">
                <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
                <span className="text-[9px] font-bold tracking-widest uppercase text-amber-200">AI PROJECTION</span>
              </div>
            </div>
            <h2 className="text-2xl font-bold">{formatAmount(forecast.projectedSpend)}</h2>
          </div>
          <div className="mt-4">
            <p className="text-[10px] opacity-90 italic leading-snug font-medium line-clamp-2">
              "{forecast.aiExplanation || 'Analyzing current pacing velocity...'}"
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid: Analytical Charts + AI Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Spending Analytics & Charts */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          
          {/* Spending Analysis Line Chart */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col min-h-[360px]" id="chart_spending_trends">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="font-bold text-slate-800 text-sm">Dynamic Cash Flow Trends</h3>
                <p className="text-[11px] text-slate-400">Daily breakdown of expenses vs incomes in the active billing month</p>
              </div>
              <div className="flex gap-2.5">
                <span className="px-2.5 py-1 bg-slate-100 text-slate-600 rounded-lg text-[10px] font-bold">Daily Logs</span>
                <span className="px-2.5 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-bold flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" /> Live Graph
                </span>
              </div>
            </div>

            {/* Recharts Component */}
            <div className="flex-1 w-full min-h-[220px]">
              {displayTrends && displayTrends.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={displayTrends} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                    <XAxis 
                      dataKey="date" 
                      tickFormatter={(val) => {
                        const parts = val.split('-');
                        return parts.length === 3 ? parts[2] : val;
                      }} 
                      stroke="#94A3B8" 
                      fontSize={10} 
                      tickLine={false} 
                    />
                    <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} />
                    <Tooltip 
                      formatter={(value: any) => [`${currencySymbol}${parseFloat(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, '']}
                      labelFormatter={(label) => formattedDate(String(label))}
                      contentStyle={{ borderRadius: '12px', border: '1px solid #E2E8F0', fontSize: '11px', fontWeight: '500' }}
                    />
                    <Line type="monotone" dataKey="expenses" stroke="#3B82F6" strokeWidth={2.5} dot={false} activeDot={{ r: 4 }} name="Expenses" />
                    <Line type="monotone" dataKey="income" stroke="#10B981" strokeWidth={1.5} dot={false} name="Income" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs gap-2">
                  <Calendar className="w-8 h-8 text-slate-300" />
                  <span>No data logging available for the trend chart.</span>
                </div>
              )}
            </div>

            {/* Bottom summary bar of the chart */}
            <div className="mt-4 pt-4 border-t border-slate-50 grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Total Salary</p>
                <p className="text-sm font-bold text-slate-700">+{formatAmount(summary.totalIncome)}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Net Saved</p>
                <p className={`text-sm font-bold ${summary.netSavings >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                  {summary.netSavings >= 0 ? '+' : '-'}{formatAmount(Math.abs(summary.netSavings))}
                </p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Pacing Speed</p>
                <p className="text-sm font-bold text-slate-700">
                  {formatAmount(summary.totalSpent / (new Date().getDate() || 1))}/day
                </p>
              </div>
            </div>
          </div>

          {/* Category Distribution Doughnut & Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Category Doughnut Chart */}
            <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex flex-col" id="chart_category_breakdown">
              <h3 className="font-bold text-slate-800 text-sm mb-4">Category Allocations</h3>
              <div className="flex-1 flex items-center justify-center min-h-[160px]">
                {displayCategories && displayCategories.length > 0 ? (
                  <div className="relative w-full h-[160px] flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={displayCategories}
                          innerRadius={50}
                          outerRadius={70}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {displayCategories.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(val: any) => [`${currencySymbol}${parseFloat(val).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, '']} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="absolute text-center">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Top Spend</p>
                      <p className="text-xs font-bold text-slate-800">
                        {displayCategories.reduce((max, c) => c.value > max.value ? c : max, displayCategories[0])?.category?.split(' ')[0] || 'None'}
                      </p>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">Add expenses to generate category distribution charts.</p>
                )}
              </div>
            </div>

            {/* Category legends card */}
            <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between" id="legend_list">
              <h3 className="font-bold text-slate-800 text-sm mb-3">Spending List</h3>
              <div className="flex flex-col gap-2.5 overflow-y-auto max-h-[160px] pr-1">
                {displayCategories && displayCategories.length > 0 ? (
                  displayCategories.map((c, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.color }}></div>
                        <span className="text-xs text-slate-600 font-medium">{c.category}</span>
                      </div>
                      <span className="text-xs font-bold text-slate-800">{currencySymbol}{c.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-400">Empty list.</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: AI Insights Panel & Recent Activities */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          
          {/* AI Insights panel with Slate-900 Theme */}
          <div className="bg-slate-900 rounded-2xl p-5 text-white flex flex-col gap-4" id="sidebar_ai_insights">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-slate-300">AI Personal Insights</h3>
              </div>
              <button
                onClick={() => onNavigate('insights')}
                className="text-[10px] text-blue-400 font-bold hover:underline"
              >
                View Full Analysis
              </button>
            </div>

            <div className="flex flex-col gap-3.5 max-h-[280px] overflow-y-auto pr-1">
              {insights && insights.length > 0 ? (
                insights.slice(0, 2).map((ins, idx) => (
                  <div key={ins.id || idx} className="p-3 bg-white/10 rounded-xl border border-white/5 flex flex-col gap-1">
                    <p className={`text-[9px] font-bold tracking-widest uppercase ${
                      ins.type === 'danger' || ins.type === 'warning' ? 'text-orange-300' : 'text-green-300'
                    }`}>
                      {ins.title || 'FINANCIAL TIP'}
                    </p>
                    <p className="text-xs text-slate-100 leading-relaxed font-normal">{ins.message}</p>
                  </div>
                ))
              ) : (
                <div className="p-4 bg-white/5 rounded-xl text-center text-xs text-slate-400">
                  AI engine compiles insights as transactions arrive.
                </div>
              )}
            </div>
          </div>

          {/* Recent Activity Card */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 flex-1 flex flex-col" id="sidebar_recent_transactions">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-slate-800 text-sm">Recent Activity</h3>
              <button
                onClick={() => onNavigate('transactions')}
                className="text-[10px] text-blue-600 font-bold hover:underline"
              >
                View Ledger
              </button>
            </div>

            <div className="flex flex-col gap-3.5 overflow-hidden">
              {expenses && expenses.length > 0 ? (
                expenses.slice(0, 4).map((exp) => (
                  <div key={exp.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${getCategoryColorClass(exp.category)}`}>
                        {getCategoryAbbr(exp.category)}
                      </div>
                      <div className="max-w-[130px] sm:max-w-none">
                        <p className="text-xs font-bold text-slate-800 truncate" title={exp.description}>
                          {exp.description}
                        </p>
                        <p className="text-[10px] text-slate-400 flex items-center gap-1">
                          {exp.category} 
                          {exp.isAiPredicted && (
                            <span className="inline-flex items-center text-[8px] font-semibold bg-blue-50 text-blue-600 px-1 rounded">AI</span>
                          )}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-slate-800">-{formatAmount(exp.amount)}</p>
                      <p className="text-[9px] text-slate-400">{formattedDate(exp.date)}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="py-8 text-center text-xs text-slate-400">
                  No expenses added yet this month.
                </div>
              )}
            </div>

            <button
              onClick={() => onOpenModal('expense')}
              className="mt-6 w-full py-2.5 bg-slate-50 text-slate-500 rounded-xl text-xs font-bold hover:bg-slate-100 hover:text-slate-700 transition-colors"
            >
              + Record New Spend
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
