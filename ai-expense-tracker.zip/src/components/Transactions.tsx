/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, Filter, Trash2, Edit3, Calendar, Tag, AlertTriangle, Sparkles, X } from 'lucide-react';
import { Expense } from '../types';

interface TransactionsProps {
  expenses: Expense[];
  onDeleteExpense: (id: string) => void;
  onEditExpense: (expense: Expense) => void;
  currency: 'USD' | 'INR';
  exchangeRate: number;
}

export default function Transactions({
  expenses,
  onDeleteExpense,
  onEditExpense,
  currency,
  exchangeRate,
}: TransactionsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const currencySymbol = currency === 'INR' ? '₹' : '$';

  const formatAmount = (usdAmount: number) => {
    const amount = currency === 'INR' ? usdAmount * exchangeRate : usdAmount;
    return `${currencySymbol}${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const categories = [
    'All',
    'Food & Dining',
    'Transport & Travel',
    'Shopping',
    'Entertainment & Subscriptions',
    'Utilities & Bills',
    'Miscellaneous',
  ];

  // Client side filters
  const filteredExpenses = expenses.filter((e) => {
    const matchesSearch =
      e.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.paymentMethod.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = selectedCategory === 'All' || e.category === selectedCategory;
    const matchesStartDate = !startDate || e.date >= startDate;
    const matchesEndDate = !endDate || e.date <= endDate;

    return matchesSearch && matchesCategory && matchesStartDate && matchesEndDate;
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Food & Dining': return 'bg-blue-50 text-blue-600 border-blue-100';
      case 'Transport & Travel': return 'bg-emerald-50 text-emerald-600 border-emerald-100';
      case 'Shopping': return 'bg-amber-50 text-amber-600 border-amber-100';
      case 'Entertainment & Subscriptions': return 'bg-pink-50 text-pink-600 border-pink-100';
      case 'Utilities & Bills': return 'bg-purple-50 text-purple-600 border-purple-100';
      default: return 'bg-slate-50 text-slate-600 border-slate-100';
    }
  };

  const formattedDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategory('All');
    setStartDate('');
    setEndDate('');
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 flex flex-col gap-6" id="ledger_view">
      {/* Header and counter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-800">Financial Ledger</h2>
          <p className="text-xs text-slate-400">View, filter, and audit all recorded transaction histories</p>
        </div>
        <div className="text-right">
          <span className="text-xs font-bold text-slate-400 bg-slate-50 px-3 py-1 rounded-lg border border-slate-100">
            {filteredExpenses.length} of {expenses.length} records shown
          </span>
        </div>
      </div>

      {/* Filter and search control panel */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-2.5 w-4.5 h-4.5 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search description..."
            className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 transition-all"
          />
        </div>

        {/* Category selector */}
        <div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 transition-all"
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                {c === 'All' ? 'All Categories' : c}
              </option>
            ))}
          </select>
        </div>

        {/* Start Date */}
        <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 border border-slate-200 rounded-xl">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0">From</span>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full text-xs focus:outline-none bg-transparent"
          />
        </div>

        {/* End Date */}
        <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 border border-slate-200 rounded-xl">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0">To</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full text-xs focus:outline-none bg-transparent"
          />
        </div>
      </div>

      {/* Clear active filter badge row */}
      {(searchTerm || selectedCategory !== 'All' || startDate || endDate) && (
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-400">Active Filters:</span>
          <button
            onClick={clearFilters}
            className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all"
          >
            Clear All Filter parameters <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Expenses Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4">Description</th>
              <th className="py-3 px-4">Category</th>
              <th className="py-3 px-4">Payment Method</th>
              <th className="py-3 px-4 text-right">Amount</th>
              <th className="py-3 px-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50 text-xs">
            {filteredExpenses.length > 0 ? (
              filteredExpenses.map((exp) => (
                <tr key={exp.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="py-3.5 px-4 font-medium text-slate-500 whitespace-nowrap">
                    {formattedDate(exp.date)}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-800">{exp.description}</span>
                      {/* Anomaly banner / alert */}
                      {exp.detectedAnomaly && (
                        <div className="mt-1 flex items-center gap-1.5 text-[10px] text-amber-600 font-semibold bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-100/50 self-start" title={exp.anomalyReason}>
                          <AlertTriangle className="w-3 h-3 shrink-0" />
                          <span>AI Anomaly Flagged</span>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getCategoryColor(exp.category)}`}>
                      {exp.category}
                      {exp.isAiPredicted && (
                        <Sparkles className="w-2.5 h-2.5" title="Predicted by AI NLP" />
                      )}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-500 font-medium whitespace-nowrap">
                    {exp.paymentMethod}
                  </td>
                  <td className="py-3.5 px-4 text-right font-bold text-slate-800 whitespace-nowrap">
                    -{formatAmount(exp.amount)}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center justify-center gap-2 opacity-80 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onEditExpense(exp)}
                        className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-slate-800 rounded-lg transition-colors"
                        title="Edit Expense"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('Are you sure you want to delete this expense transaction?')) {
                            onDeleteExpense(exp.id);
                          }
                        }}
                        className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
                        title="Delete Record"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="py-12 text-center text-slate-400">
                  No transaction records match the specified query conditions.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
