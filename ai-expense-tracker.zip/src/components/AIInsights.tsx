/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, TrendingUp, AlertOctagon, HelpCircle, AlertTriangle, Lightbulb, TrendingDown, Target, Brain } from 'lucide-react';
import { Expense } from '../types';

interface AIInsightsProps {
  expenses: Expense[];
  forecast: {
    currentSpend: number;
    projectedSpend: number;
    isOverBudget: boolean;
    confidenceInterval: [number, number];
    aiExplanation?: string;
  };
  insights: {
    id: string;
    type: 'danger' | 'warning' | 'success' | 'info';
    title: string;
    message: string;
  }[];
  currency: 'USD' | 'INR';
  exchangeRate: number;
}

export default function AIInsights({ expenses, forecast, insights, currency, exchangeRate }: AIInsightsProps) {
  const anomalies = expenses.filter(e => e.detectedAnomaly);

  const currencySymbol = currency === 'INR' ? '₹' : '$';

  const formatAmount = (usdAmount: number) => {
    const amount = currency === 'INR' ? usdAmount * exchangeRate : usdAmount;
    return `${currencySymbol}${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'danger': return <AlertOctagon className="w-5 h-5 text-red-500 shrink-0" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />;
      case 'success': return <Lightbulb className="w-5 h-5 text-green-500 shrink-0" />;
      default: return <Brain className="w-5 h-5 text-blue-500 shrink-0" />;
    }
  };

  const getInsightColor = (type: string) => {
    switch (type) {
      case 'danger': return 'bg-red-50 border-red-100 text-red-900';
      case 'warning': return 'bg-amber-50 border-amber-100 text-amber-900';
      case 'success': return 'bg-green-50 border-green-100 text-green-900';
      default: return 'bg-blue-50 border-blue-100 text-blue-900';
    }
  };

  return (
    <div className="flex flex-col gap-6" id="ai_insights_view">
      
      {/* Top Banner: Predictive AI Forecast */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800" id="forecast_insight_hero">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400 animate-pulse" />
              <h3 className="text-xs font-bold uppercase tracking-widest text-slate-300">Financial Forecast Engine</h3>
            </div>
            <h2 className="text-xl font-bold tracking-tight">Month-End Spending Projection</h2>
            <p className="text-xs text-slate-400">Time-series forecasting combining daily run-rates and historical averages</p>
          </div>

          {/* Quick numbers */}
          <div className="flex gap-8 border-t md:border-t-0 md:border-l border-slate-800 pt-4 md:pt-0 md:pl-8">
            <div>
              <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Current Spend</p>
              <p className="text-lg font-bold">{formatAmount(forecast.currentSpend)}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Projected Spend</p>
              <p className={`text-lg font-bold ${forecast.isOverBudget ? 'text-red-400' : 'text-emerald-400'}`}>
                {formatAmount(forecast.projectedSpend)}
              </p>
            </div>
          </div>
        </div>

        {/* Visual Forecast Slider Interval */}
        <div className="mt-8 bg-white/5 p-4 rounded-xl border border-white/5 flex flex-col gap-2">
          <div className="flex justify-between text-[11px] text-slate-400">
            <span>Minimum Bound: {formatAmount(forecast.confidenceInterval[0])}</span>
            <span className="font-bold text-slate-200">Confidence Interval (90% Probable)</span>
            <span>Maximum Bound: {formatAmount(forecast.confidenceInterval[1])}</span>
          </div>
          {/* Interval Bar representation */}
          <div className="relative h-2 w-full bg-white/10 rounded-full mt-1 overflow-hidden">
            <div 
              className="absolute h-full bg-blue-500 rounded-full" 
              style={{ 
                left: '20%', 
                width: '60%' 
              }}
            ></div>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed font-normal mt-2 italic">
            "{forecast.aiExplanation || 'Analyzing current transaction volume to construct statistical spending pathways...'}"
          </p>
        </div>
      </div>

      {/* Grid: Live Suggestions vs Anomaly Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Personalized Insights Feed */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <div className="flex items-center gap-2 mb-6">
              <Brain className="w-5 h-5 text-blue-600" />
              <div>
                <h3 className="font-bold text-slate-800 text-sm">Advisory Hub</h3>
                <p className="text-xs text-slate-400">Dynamic recommendations generated from your active financial context</p>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              {insights && insights.length > 0 ? (
                insights.map((ins) => (
                  <div key={ins.id} className={`p-4 rounded-xl border flex gap-3.5 ${getInsightColor(ins.type)}`}>
                    {getInsightIcon(ins.type)}
                    <div>
                      <h4 className="font-bold text-xs">{ins.title}</h4>
                      <p className="text-xs opacity-90 mt-1 leading-relaxed font-normal">{ins.message}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-slate-400 text-xs">
                  Reviewing current allocations to assemble advice...
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: AI Anomaly Alerts */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex-1 flex flex-col">
            <div className="flex items-center gap-2 mb-4">
              <AlertOctagon className="w-5 h-5 text-amber-500 animate-pulse" />
              <div>
                <h3 className="font-bold text-slate-800 text-sm">Anomaly Tracking</h3>
                <p className="text-xs text-slate-400">Transactions exceeding normal standard deviations</p>
              </div>
            </div>

            <div className="flex flex-col gap-4 overflow-y-auto max-h-[360px] pr-1 flex-1">
              {anomalies && anomalies.length > 0 ? (
                anomalies.map((a) => (
                  <div key={a.id} className="p-3 bg-amber-50/50 border border-amber-100/50 rounded-xl flex flex-col gap-1.5">
                    <div className="flex justify-between items-start">
                      <span className="text-xs font-bold text-slate-800">{a.description}</span>
                      <span className="text-xs font-bold text-amber-700">-{formatAmount(a.amount)}</span>
                    </div>
                    <p className="text-[10px] text-amber-800 leading-relaxed font-medium">
                      {a.anomalyReason || `Unusually high spend in "${a.category}". exceeds regular benchmarks.`}
                    </p>
                    <span className="text-[9px] text-slate-400 uppercase font-semibold">
                      Recorded on {new Date(a.date).toLocaleDateString()} • {a.category}
                    </span>
                  </div>
                ))
              ) : (
                <div className="py-12 flex-1 flex flex-col items-center justify-center text-center text-xs text-slate-400 gap-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                  <span>No unusual transaction anomalies detected in this period. Outstanding budget pacing!</span>
                </div>
              )}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}

// Inline helper mock component
function CheckCircle2(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
