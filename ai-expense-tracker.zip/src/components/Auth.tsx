/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, Sparkles, LogIn, UserPlus, Info } from 'lucide-react';

interface AuthProps {
  onLoginSuccess: (token: string, user: { email: string }) => void;
}

export default function Auth({ onLoginSuccess }: AuthProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Auto-fill demo account details for the user
  const useDemoAccount = () => {
    setEmail('demo@finai.com');
    setPassword('password123');
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    setError('');
    setIsLoading(true);

    try {
      const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong');
      }

      onLoginSuccess(data.token, data.user);
    } catch (err: any) {
      setError(err.message || 'Connection to authentication server failed.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 text-slate-900 font-sans p-6 items-center justify-center">
      {/* Title Header */}
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-sm">F</div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-800">
          FinAI <span className="text-blue-600">Assistant</span>
        </h1>
      </div>

      {/* Main Auth Card */}
      <div className="w-full max-w-md bg-white p-8 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800">
            {isLogin ? 'Welcome Back' : 'Create Student Account'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isLogin
              ? 'Sign in to access your intelligent personal finance hub.'
              : 'Register your email to begin tracking expenses and running ML forecasts.'}
          </p>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-xs text-red-600 flex items-start gap-2">
            <Info className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="student@college.edu"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl text-sm hover:bg-blue-700 transition-colors shadow-sm flex items-center justify-center gap-2 mt-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : isLogin ? (
              <>
                <LogIn className="w-4 h-4" />
                <span>Sign In</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                <span>Register Account</span>
              </>
            )}
          </button>
        </form>

        {/* Demo Account Quick Access - Highly Helpful */}
        {isLogin && (
          <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl flex flex-col gap-2">
            <div className="flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
              <div>
                <p className="text-xs font-bold text-blue-800">Explore Demo Account</p>
                <p className="text-[11px] text-blue-600 leading-relaxed mt-0.5">
                  We preloaded this app with realistic expenses, recurring charges, and budgets so you can instantly see the charts and AI capabilities!
                </p>
              </div>
            </div>
            <button
              onClick={useDemoAccount}
              type="button"
              className="self-end px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-bold transition-all shadow-sm"
            >
              Autofill Student Demo
            </button>
          </div>
        )}

        <div className="flex items-center justify-center text-xs text-slate-500 mt-2 border-t border-slate-100 pt-4">
          <span>
            {isLogin ? "Don't have an account yet?" : 'Already have a student account?'}
          </span>
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              setError('');
            }}
            className="ml-1.5 font-bold text-blue-600 hover:underline"
          >
            {isLogin ? 'Register Here' : 'Log In Here'}
          </button>
        </div>
      </div>

      <div className="mt-8 flex items-center gap-2 text-[11px] text-slate-400 font-medium">
        <Shield className="w-3.5 h-3.5" />
        <span>FinAI Sandbox Secure Workspace Client • Local Cache Persisted</span>
      </div>
    </div>
  );
}
