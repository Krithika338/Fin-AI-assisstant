/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Target, CreditCard, Calendar, Plus, Trash2, ArrowUpRight, DollarSign } from 'lucide-react';

interface BudgetsProps {
  budgetsStatus: any[];
  onSetBudget: (category: string, amount: number, month: string) => void;
  onDeleteBudget: (id: string) => void;
  currency: 'USD' | 'INR';
  exchangeRate: number;
}

export default function Budgets({ budgetsStatus, onSetBudget, onDeleteBudget, currency, exchangeRate }: BudgetsProps) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [amount, setAmount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currencySymbol = currency === 'INR' ? '₹' : '$';

  const formatAmount = (usdAmount: number) => {
    const amount = currency === 'INR' ? usdAmount * exchangeRate : usdAmount;
    return `${currencySymbol}${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatAmountNoDecimals = (usdAmount: number) => {
    const amount = currency === 'INR' ? usdAmount * exchangeRate : usdAmount;
    return `${currencySymbol}${amount.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  };

  const categories = [
    'All',
    'Food & Dining',
    'Transport & Travel',
    'Shopping',
    'Entertainment & Subscriptions',
    'Utilities & Bills',
    'Miscellaneous',
  ];

  const currentMonthStr = new Date().toISOString().substring(0, 7); // YYYY-MM

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (!selectedCategory || isNaN(val) || val <= 0) return;

    setIsSubmitting(true);
    try {
      // If active currency is INR, convert the user's input limit from INR to USD for API storage
      const usdValue = currency === 'INR' ? val / exchangeRate : val;
      await onSetBudget(selectedCategory, usdValue, currentMonthStr);
      setAmount('');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getProgressColor = (percentage: number) => {
    if (percentage > 95) return 'bg-red-500';
    if (percentage > 75) return 'bg-amber-500';
    return 'bg-blue-600';
  };

  const getProgressBg = (percentage: number) => {
    if (percentage > 95) return 'bg-red-50 text-red-600 border-red-100';
    if (percentage > 75) return 'bg-amber-50 text-amber-600 border-amber-100';
    return 'bg-blue-50 text-blue-600 border-blue-100';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="budgets_view">
      
      {/* Left side: Set target budget limits */}
      <div className="lg:col-span-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-100 h-fit">
        <h3 className="font-bold text-slate-800 text-sm mb-1.5 flex items-center gap-1.5">
          <Target className="w-4 h-4 text-blue-600" />
          <span>Configure Target Target</span>
        </h3>
        <p className="text-xs text-slate-400 mb-6">Establish spending limits to protect your savings pacing</p>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Target Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === 'All' ? 'Overall Monthly Budget (All)' : c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Limit Amount ({currencySymbol})
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-slate-400 text-sm font-bold">{currencySymbol}</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                min="1"
                step="any"
                className="w-full pl-7.5 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-blue-500 focus:bg-white transition-all font-bold"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting || !amount}
            className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl text-xs hover:bg-blue-700 transition-colors shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50 mt-2"
          >
            {isSubmitting ? (
              <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5" />
                <span>Save Target Limit</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Right side: Current limits progress list */}
      <div className="lg:col-span-8 flex flex-col gap-5">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="font-bold text-slate-800 text-sm">Active Enforcements</h3>
              <p className="text-xs text-slate-400">Budget pacing metrics for {currentMonthStr}</p>
            </div>
          </div>

          <div className="flex flex-col gap-5">
            {budgetsStatus && budgetsStatus.length > 0 ? (
              budgetsStatus.map((b) => (
                <div key={b.id} className="p-4 bg-slate-50/50 rounded-xl border border-slate-100 flex flex-col gap-3 group relative">
                  
                  {/* Title & Limits */}
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-slate-800 text-xs">
                        {b.category === 'All' ? 'Overall Monthly spending (All)' : b.category}
                      </h4>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Spent {formatAmount(b.spent)} of {formatAmountNoDecimals(b.limit)}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className={`px-2 py-0.5 rounded-lg text-[9px] font-bold border ${getProgressBg(b.percentageUsed)}`}>
                        {b.percentageUsed}% Pacing
                      </span>
                      <button
                        onClick={() => {
                          if (confirm(`Remove budget for ${b.category}?`)) {
                            onDeleteBudget(b.id);
                          }
                        }}
                        className="p-1 text-slate-400 hover:text-red-500 rounded hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all"
                        title="Remove Limit"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Pacing progress bar */}
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${getProgressColor(b.percentageUsed)}`}
                      style={{ width: `${Math.min(100, b.percentageUsed)}%` }}
                    ></div>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-12 text-center text-slate-400 text-xs">
                No active budget limits configured. Define some above!
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
}
