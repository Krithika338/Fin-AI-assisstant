/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sparkles, Target, DollarSign, LogOut, ShieldAlert, Sparkle, Menu, User, RefreshCw, Layers } from 'lucide-react';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import Transactions from './components/Transactions';
import Budgets from './components/Budgets';
import Income from './components/Income';
import AIInsights from './components/AIInsights';
import ExpenseModal from './components/ExpenseModal';
import { Expense } from './types';

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [user, setUser] = useState<{ email: string } | null>(null);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isLoading, setIsLoading] = useState(false);

  // Currency converter state variables
  const [currency, setCurrency] = useState<'USD' | 'INR'>('USD');
  const [exchangeRate, setExchangeRate] = useState<number>(83.5);
  const [isFetchingRate, setIsFetchingRate] = useState(false);

  // Core financial state
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [budgetsStatus, setBudgetsStatus] = useState<any[]>([]);
  const [incomes, setIncomes] = useState<any[]>([]);
  const [summary, setSummary] = useState({
    totalSpent: 0,
    totalIncome: 0,
    netSavings: 0,
    budgetBurnRate: 0,
    budgetLimit: 2000,
  });
  const [categoriesBreakdown, setCategoriesBreakdown] = useState<any[]>([]);
  const [trends, setTrends] = useState<any[]>([]);
  const [forecast, setForecast] = useState({
    currentSpend: 0,
    projectedSpend: 0,
    isOverBudget: false,
    confidenceInterval: [0, 0] as [number, number],
    aiExplanation: '',
  });
  const [insights, setInsights] = useState<any[]>([]);

  // Modals state
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [editExpense, setEditExpense] = useState<Expense | null>(null);

  // Fetch live exchange rate from a public API
  useEffect(() => {
    const fetchLiveRate = async () => {
      setIsFetchingRate(true);
      try {
        const response = await fetch('https://open.er-api.com/v6/latest/USD');
        if (response.ok) {
          const data = await response.json();
          if (data && data.rates && data.rates.INR) {
            setExchangeRate(data.rates.INR);
          }
        }
      } catch (err) {
        console.warn('Unable to get live USD-INR rate, falling back to 83.5:', err);
      } finally {
        setIsFetchingRate(false);
      }
    };
    fetchLiveRate();
  }, []);

  // Headers helper for authenticated requests
  const getAuthHeaders = () => {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    };
  };

  // Check auth and fetch me on load
  useEffect(() => {
    if (token) {
      localStorage.setItem('token', token);
      fetchUserProfile();
    } else {
      localStorage.removeItem('token');
      setUser(null);
    }
  }, [token]);

  // Fetch all app stats when user and token are ready
  useEffect(() => {
    if (user && token) {
      fetchAllData();
    }
  }, [user, token]);

  const fetchUserProfile = async () => {
    try {
      const response = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      if (response.ok) {
        const data = await response.json();
        setUser({ email: data.email });
      } else {
        // Token must be stale
        handleLogout();
      }
    } catch {
      handleLogout();
    }
  };

  const fetchAllData = async () => {
    setIsLoading(true);
    try {
      await Promise.all([
        fetchExpenses(),
        fetchBudgets(),
        fetchIncomes(),
        fetchSummary(),
        fetchCategoriesBreakdown(),
        fetchTrends(),
        fetchForecast(),
        fetchInsights(),
      ]);
    } catch (e) {
      console.error('Failed to load application telemetry metrics:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchExpenses = async () => {
    const response = await fetch('/api/expenses', { headers: getAuthHeaders() });
    if (response.ok) {
      const data = await response.json();
      setExpenses(data);
    }
  };

  const fetchBudgets = async () => {
    const response = await fetch('/api/budgets/status', { headers: getAuthHeaders() });
    if (response.ok) {
      const data = await response.json();
      setBudgetsStatus(data);
    }
  };

  const fetchIncomes = async () => {
    const response = await fetch('/api/income', { headers: getAuthHeaders() });
    if (response.ok) {
      const data = await response.json();
      setIncomes(data);
    }
  };

  const fetchSummary = async () => {
    const response = await fetch('/api/analytics/summary', { headers: getAuthHeaders() });
    if (response.ok) {
      const data = await response.json();
      setSummary(data);
    }
  };

  const fetchCategoriesBreakdown = async () => {
    const response = await fetch('/api/analytics/categories', { headers: getAuthHeaders() });
    if (response.ok) {
      const data = await response.json();
      setCategoriesBreakdown(data);
    }
  };

  const fetchTrends = async () => {
    const response = await fetch('/api/analytics/trends', { headers: getAuthHeaders() });
    if (response.ok) {
      const data = await response.json();
      setTrends(data);
    }
  };

  const fetchForecast = async () => {
    const response = await fetch('/api/ai/forecast', { headers: getAuthHeaders() });
    if (response.ok) {
      const data = await response.json();
      setForecast(data);
    }
  };

  const fetchInsights = async () => {
    const response = await fetch('/api/ai/insights', { headers: getAuthHeaders() });
    if (response.ok) {
      const data = await response.json();
      setInsights(data);
    }
  };

  const handleLoginSuccess = (newToken: string, loggedUser: { email: string }) => {
    setToken(newToken);
    setUser(loggedUser);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
  };

  // CRUD Expense Save Action (Add / Edit)
  const handleSaveExpense = async (data: any) => {
    const isEdit = !!data.id;
    const endpoint = isEdit ? `/api/expenses/${data.id}` : '/api/expenses';
    const method = isEdit ? 'PUT' : 'POST';

    const response = await fetch(endpoint, {
      method,
      headers: getAuthHeaders(),
      body: JSON.stringify({
        amount: data.amount,
        date: data.date,
        description: data.description,
        category: data.category,
        paymentMethod: data.paymentMethod,
        isRecurring: data.isRecurring,
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'Failed to save expense log');
    }

    // Success -> reload all states
    await fetchAllData();
  };

  const handleDeleteExpense = async (id: string) => {
    const response = await fetch(`/api/expenses/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });

    if (response.ok) {
      await fetchAllData();
    }
  };

  const handleEditExpenseTrigger = (expense: Expense) => {
    setEditExpense(expense);
    setIsExpenseModalOpen(true);
  };

  // Budgets saving
  const handleSetBudget = async (category: string, amount: number, month: string) => {
    const response = await fetch('/api/budgets', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ category, amount, month }),
    });

    if (response.ok) {
      await fetchAllData();
    }
  };

  const handleDeleteBudget = async (id: string) => {
    const response = await fetch(`/api/budgets/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });

    if (response.ok) {
      await fetchAllData();
    }
  };

  // Incomes saving
  const handleAddIncome = async (amount: number, date: string, source: string, description: string) => {
    const response = await fetch('/api/income', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ amount, date, source, description }),
    });

    if (response.ok) {
      await fetchAllData();
    }
  };

  const handleDeleteIncome = async (id: string) => {
    const response = await fetch(`/api/income/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });

    if (response.ok) {
      await fetchAllData();
    }
  };

  // Quick Action handler from dashboard/footer
  const handleOpenQuickModal = (type: 'expense' | 'budget' | 'income') => {
    if (type === 'expense') {
      setEditExpense(null);
      setIsExpenseModalOpen(true);
    } else if (type === 'budget') {
      setActiveTab('budgets');
    } else if (type === 'income') {
      setActiveTab('income');
    }
  };

  if (!token || !user) {
    return <Auth onLoginSuccess={handleLoginSuccess} />;
  }

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard
            expenses={expenses}
            budgets={budgetsStatus}
            summary={summary}
            categoriesBreakdown={categoriesBreakdown}
            trends={trends}
            forecast={forecast}
            insights={insights}
            onNavigate={setActiveTab}
            onOpenModal={handleOpenQuickModal}
            currency={currency}
            exchangeRate={exchangeRate}
          />
        );
      case 'transactions':
        return (
          <Transactions
            expenses={expenses}
            onDeleteExpense={handleDeleteExpense}
            onEditExpense={handleEditExpenseTrigger}
            currency={currency}
            exchangeRate={exchangeRate}
          />
        );
      case 'budgets':
        return (
          <Budgets
            budgetsStatus={budgetsStatus}
            onSetBudget={handleSetBudget}
            onDeleteBudget={handleDeleteBudget}
            currency={currency}
            exchangeRate={exchangeRate}
          />
        );
      case 'income':
        return (
          <Income
            incomes={incomes}
            onAddIncome={handleAddIncome}
            onDeleteIncome={handleDeleteIncome}
            currency={currency}
            exchangeRate={exchangeRate}
          />
        );
      case 'insights':
        return (
          <AIInsights
            expenses={expenses}
            forecast={forecast}
            insights={insights}
            currency={currency}
            exchangeRate={exchangeRate}
          />
        );
      default:
        return <div className="text-center py-12 text-slate-400">View not found.</div>;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 text-slate-900 font-sans p-6 overflow-x-hidden">
      
      {/* Header Container */}
      <header className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8 px-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-sm">F</div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-800">
              FinAI <span className="text-blue-600">Assistant</span>
            </h1>
          </div>
        </div>

        {/* Dynamic Navigation Dock */}
        <nav className="flex flex-wrap items-center justify-center gap-2 sm:gap-6 text-xs sm:text-sm font-medium text-slate-500">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`pb-1 px-1 transition-colors border-b-2 font-semibold ${
              activeTab === 'dashboard' ? 'text-blue-600 border-blue-600' : 'border-transparent hover:text-slate-800'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('transactions')}
            className={`pb-1 px-1 transition-colors border-b-2 font-semibold ${
              activeTab === 'transactions' ? 'text-blue-600 border-blue-600' : 'border-transparent hover:text-slate-800'
            }`}
          >
            Transactions
          </button>
          <button
            onClick={() => setActiveTab('budgets')}
            className={`pb-1 px-1 transition-colors border-b-2 font-semibold ${
              activeTab === 'budgets' ? 'text-blue-600 border-blue-600' : 'border-transparent hover:text-slate-800'
            }`}
          >
            Budgets
          </button>
          <button
            onClick={() => setActiveTab('income')}
            className={`pb-1 px-1 transition-colors border-b-2 font-semibold ${
              activeTab === 'income' ? 'text-blue-600 border-blue-600' : 'border-transparent hover:text-slate-800'
            }`}
          >
            Income Flows
          </button>
          <button
            onClick={() => setActiveTab('insights')}
            className={`pb-1 px-1 transition-colors border-b-2 font-semibold flex items-center gap-1.5 ${
              activeTab === 'insights' ? 'text-blue-600 border-blue-600' : 'border-transparent hover:text-slate-800'
            }`}
          >
            <Sparkle className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
            <span>AI Insights</span>
          </button>
        </nav>

        {/* Account and Info card with Live Currency Toggle */}
        <div className="flex items-center gap-4 border-l border-slate-200 pl-4">
          <div className="flex flex-col items-end gap-1">
            {/* Minimalist Switch Toggle */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200" id="currency_toggle">
              <button
                onClick={() => setCurrency('USD')}
                className={`px-2.5 py-1 rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  currency === 'USD' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-400 hover:text-slate-600'
                }`}
                title="Switch view to United States Dollar"
              >
                USD ($)
              </button>
              <button
                onClick={() => setCurrency('INR')}
                className={`px-2.5 py-1 rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  currency === 'INR' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-400 hover:text-slate-600'
                }`}
                title="Switch view to Indian Rupee"
              >
                INR (₹)
              </button>
            </div>
            {currency === 'INR' && (
              <span className="text-[9px] font-semibold text-slate-400 animate-fade-in" id="exchange_rate_indicator">
                1 USD = ₹{exchangeRate.toFixed(2)}
              </span>
            )}
          </div>

          <div className="text-right hidden sm:block">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Student Account</p>
            <p className="text-xs font-bold text-slate-700 truncate max-w-[120px]">{user.email}</p>
          </div>
          <button
            onClick={handleLogout}
            className="p-2 bg-slate-100 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-xl transition-all shadow-sm flex items-center justify-center cursor-pointer"
            title="Log Out Session"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Dynamic Workspace Component */}
      <main className="flex-1 w-full max-w-7xl mx-auto">
        {isLoading && expenses.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4 text-slate-400">
            <RefreshCw className="w-8 h-8 animate-spin text-blue-600" />
            <span className="text-xs font-semibold">Synchronizing with financial database sandbox...</span>
          </div>
        ) : (
          renderActiveView()
        )}
      </main>

      {/* Footer Controls Container */}
      <footer className="mt-8 flex flex-col md:flex-row justify-between items-center gap-4 bg-white p-4 rounded-2xl shadow-sm border border-slate-100 w-full max-w-7xl mx-auto">
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => handleOpenQuickModal('expense')}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
          >
            + Add Expense
          </button>
          <button
            onClick={() => handleOpenQuickModal('budget')}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold transition-all border border-slate-200/50"
          >
            Set Budget Limit
          </button>
          <button
            onClick={() => handleOpenQuickModal('income')}
            className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 rounded-xl text-xs font-bold transition-all border border-emerald-200/50"
          >
            + Record Income
          </button>
          <button
            onClick={fetchAllData}
            className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-500 rounded-xl text-xs font-bold transition-all border border-slate-200/30"
            title="Refresh All Database States"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Live statuses */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Sandbox API: Live</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">AI Classifier: Online</span>
          </div>
        </div>
      </footer>

      {/* Expense Modal Wrapper */}
      <ExpenseModal
        isOpen={isExpenseModalOpen}
        onClose={() => {
          setIsExpenseModalOpen(false);
          setEditExpense(null);
        }}
        onSave={handleSaveExpense}
        editExpense={editExpense}
        currency={currency}
        exchangeRate={exchangeRate}
      />
    </div>
  );
}
